# Audit evidence draft

Synthetic evidence and document drafts. No product approval, risk acceptance or e-signature is implied. Verify every checksum before use. Snapshots retain prior revisions used by manifests.
