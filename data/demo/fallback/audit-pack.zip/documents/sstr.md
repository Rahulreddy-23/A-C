# Software System Test Report

<!-- section:purpose_scope -->
## Purpose and scope

<!-- dhf-claim:ca8f9d9e337dccd4 -->
The operator needs to set and monitor infusion without relying on undocumented device state. The controller must make its current mode visible and retain objective verification evidence for later review. [UN-001@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/1?rev=1)

<!-- dhf-claim:3aa2527bfe9b9016 -->
The operator needs to limit delivered volume without relying on undocumented device state. The controller must make its current mode visible and retain objective verification evidence for later review. [UN-002@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/2?rev=1)

<!-- dhf-claim:a3e3cfd768badde6 -->
The operator needs to detect unsafe sensor conditions without relying on undocumented device state. The controller must make its current mode visible and retain objective verification evidence for later review. [UN-003@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/3?rev=1)


<!-- endsection:purpose_scope -->

<!-- section:references -->
## Requirements baseline under test

| Requirement | Revision | Title | 
| --- | --- | --- | 
| [SRS-001](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/22?rev=1) | 1 | Flow bounds | 
| [SRS-002](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/23?rev=1) | 1 | Volume limit | 
| [SRS-003](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/24?rev=1) | 1 | Start interlock | 
| [SRS-004](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/25?rev=1) | 1 | Pause control | 
| [SRS-005](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/26?rev=1) | 1 | Stop control | 
| [SRS-006](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/27?rev=1) | 1 | Rate conversion | 
| [SRS-007](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/28?rev=1) | 1 | Dose calculation | 
| [SRS-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/29?rev=1) | 1 | Air detection | 
| [SRS-009](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/30?rev=1) | 1 | Pressure sampling | 
| [SRS-010](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/31?rev=1) | 1 | Sensor diagnostics | 
| [SRS-011](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/32?rev=1) | 1 | Alarm priority | 
| [SRS-012](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/33?rev=1) | 1 | Alarm latch | 
| [SRS-013](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/34?rev=1) | 1 | Alarm acknowledgement | 
| [SRS-014](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/35?rev=1) | 1 | Audible alarm | 
| [SRS-015](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/36?rev=1) | 1 | Display status | 
| [SRS-016](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/37?rev=1) | 1 | Input validation | 
| [SRS-017](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/38?rev=1) | 1 | Configuration confirmation | 
| [SRS-018](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/39?rev=1) | 1 | Drug limit validation | 
| [SRS-019](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/40?rev=1) | 1 | Drug lookup | 
| [SRS-020](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/41?rev=1) | 1 | Library checksum | 
| [SRS-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/42?rev=2) | 2 | Occlusion threshold | 
| [SRS-022](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/43?rev=1) | 1 | Pressure filtering | 
| [SRS-023](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | 1 | Sensor calibration | 
| [SRS-024](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/45?rev=1) | 1 | Event persistence | 
| [SRS-025](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/46?rev=1) | 1 | Log integrity | 
| [SRS-026](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/47?rev=1) | 1 | Communication framing | 
| [SRS-027](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/48?rev=1) | 1 | Communication timeout | 
| [SRS-028](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/49?rev=1) | 1 | Delivery estimation | 
| [SRS-029](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/50?rev=1) | 1 | Watchdog | 
| [SRS-030](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/51?rev=2) | 2 | Power loss recovery | 
| [SRS-031](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/52?rev=1) | 1 | Time validation | 
| [SRS-032](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/53?rev=1) | 1 | Residual anomaly display | 
| [SRS-033](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/54?rev=1) | 1 | Export audit records | 
| [SRS-034](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/55?rev=1) | 1 | Service access policy | 
| [SRS-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | 1 | Localization selection | 
| [RUN-2](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2) | 1 | Release 1.1 verification retest | 
| [RUN-3](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/3) | 1 | Release 1.1 occlusion retest | 


<!-- endsection:references -->

<!-- section:test_environment -->
## Test environment

| Environment | 
| --- | 
| Synthetic bench simulator | 


<!-- endsection:test_environment -->

<!-- section:results_summary -->
## Summary of results

| Release | Total | Passed | Failed | Blocked | Not run | 
| --- | --- | --- | --- | --- | --- | 
| 1.1 | 40 | 38 | 2 | 0 | 0 | 


<!-- endsection:results_summary -->

<!-- section:results_by_requirement -->
## Results by requirement

| Requirement | Rev | Components | Software units | Changes | Test cases | Latest results | 
| --- | --- | --- | --- | --- | --- | --- | 
| [SRS-001](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/22?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCd5ed9fe298cdc7b6f1c65e14a172069ca3abf5b5) | [PR-2](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/2) | [TC-001](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/77?rev=1)<br>[TC-033](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/109?rev=1) | test case: [TC-001](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/77?rev=1); result: [RES-2-001](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/1); outcome: Passed<br>test case: [TC-033](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/109?rev=1); result: [RES-2-033](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/33); outcome: Passed | 
| [SRS-002](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/23?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-infusion_volume@0b716c6e](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCd5ed9fe298cdc7b6f1c65e14a172069ca3abf5b5) | [PR-2](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/2) | [TC-002](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/78?rev=1)<br>[TC-034](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/110?rev=1) | test case: [TC-002](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/78?rev=1); result: [RES-2-002](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/2); outcome: Passed<br>test case: [TC-034](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/110?rev=1); result: [RES-2-034](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/34); outcome: Passed | 
| [SRS-003](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/24?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCd5ed9fe298cdc7b6f1c65e14a172069ca3abf5b5) | [PR-2](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/2) | [TC-003](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/79?rev=1)<br>[TC-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/111?rev=1) | test case: [TC-003](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/79?rev=1); result: [RES-2-003](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/3); outcome: Passed<br>test case: [TC-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/111?rev=1); result: [RES-2-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/35); outcome: Passed | 
| [SRS-004](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/25?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCd5ed9fe298cdc7b6f1c65e14a172069ca3abf5b5) | [PR-2](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/2) | [TC-004](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/80?rev=1)<br>[TC-036](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/112?rev=1) | test case: [TC-004](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/80?rev=1); result: [RES-2-004](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/4); outcome: Passed<br>test case: [TC-036](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/112?rev=1); result: [RES-2-036](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/36); outcome: Passed | 
| [SRS-005](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/26?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCd5ed9fe298cdc7b6f1c65e14a172069ca3abf5b5) | [PR-2](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/2) | [TC-005](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/81?rev=1)<br>[TC-037](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/113?rev=1) | test case: [TC-005](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/81?rev=1); result: [RES-2-005](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/5); outcome: Passed<br>test case: [TC-037](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/113?rev=1); result: [RES-2-037](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/37); outcome: Passed | 
| [SRS-006](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/27?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-infusion_motor@eb1bd363](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCd5ed9fe298cdc7b6f1c65e14a172069ca3abf5b5) | [PR-2](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/2) | [TC-006](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/82?rev=1)<br>[TC-038](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/114?rev=1) | test case: [TC-006](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/82?rev=1); result: [RES-2-006](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/6); outcome: Passed<br>test case: [TC-038](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/114?rev=1); result: [RES-2-038](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/38); outcome: Passed | 
| [SRS-007](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/28?rev=1) | 1 | [COMP-05@17b6bad7](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-drug_limits@e7d7f0a4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GCe76df834d4f13b26458559daf65c894d6d59f7ba) | [PR-5](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/5) | [TC-007](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/83?rev=1)<br>[TC-039](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/115?rev=1) | test case: [TC-007](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/83?rev=1); result: [RES-2-007](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/7); outcome: Passed<br>test case: [TC-039](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/115?rev=1); result: [RES-2-039](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/39); outcome: Passed | 
| [SRS-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/29?rev=1) | 1 | [COMP-03@9ae26fe4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-sensor_air@f8cd0f72](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC7a0e2fbd85d24478ad55231b8952528126fcfd9b) | [PR-3](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/3) | [TC-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/84?rev=1) | test case: [TC-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/84?rev=1); result: [RES-2-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/8); outcome: Failed | 
| [SRS-009](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/30?rev=1) | 1 | [COMP-03@9ae26fe4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-sensor_pressure@a1d3651b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GCb0036579f0c7a3689c502323bca2f9f6b8057806) | [PR-3](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/3) | [TC-009](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/85?rev=1) | test case: [TC-009](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/85?rev=1); result: [RES-2-009](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/9); outcome: Passed | 
| [SRS-010](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/31?rev=1) | 1 | [COMP-03@9ae26fe4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-sensor_air@f8cd0f72](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC7a0e2fbd85d24478ad55231b8952528126fcfd9b) | [PR-3](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/3) | [TC-010](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/86?rev=1) | test case: [TC-010](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/86?rev=1); result: [RES-2-010](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/10); outcome: Passed | 
| [SRS-011](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/32?rev=1) | 1 | [COMP-04@eec25a71](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-alarm_priority@f71bb757](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GC213e9b84cbe52665a9eb94b24bff4ca5705fa6a5) | [PR-4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/4) | [TC-011](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/87?rev=1)<br>[TC-012](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/88?rev=1) | test case: [TC-011](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/87?rev=1); result: [RES-2-011](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/11); outcome: Passed<br>test case: [TC-012](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/88?rev=1); result: [RES-2-012](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/12); outcome: Passed | 
| [SRS-012](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/33?rev=1) | 1 | [COMP-04@eec25a71](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-alarm_latch@b36fa4fc](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC213e9b84cbe52665a9eb94b24bff4ca5705fa6a5) | [PR-4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/4) | — | — | 
| [SRS-013](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/34?rev=1) | 1 | [COMP-04@eec25a71](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-alarm_latch@b36fa4fc](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC213e9b84cbe52665a9eb94b24bff4ca5705fa6a5) | [PR-4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/4) | [TC-013](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/89?rev=1) | test case: [TC-013](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/89?rev=1); result: [RES-2-013](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/13); outcome: Passed | 
| [SRS-014](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/35?rev=1) | 1 | [COMP-04@eec25a71](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-alarm_audio@220f842d](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GC213e9b84cbe52665a9eb94b24bff4ca5705fa6a5) | [PR-4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/4) | [TC-014](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/90?rev=1) | test case: [TC-014](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/90?rev=1); result: [RES-2-014](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/14); outcome: Passed | 
| [SRS-015](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/36?rev=1) | 1 | [COMP-01@b128b9c4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-ui_status@4d866549](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_status.py&version=GC19a676f57c68051681fbb502cba42210350e10ce) | [PR-1](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/1) | [TC-015](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/91?rev=1) | test case: [TC-015](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/91?rev=1); result: [RES-2-015](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/15); outcome: Passed | 
| [SRS-016](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/37?rev=1) | 1 | [COMP-01@b128b9c4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-ui_input@2e563f7b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_input.py&version=GC19a676f57c68051681fbb502cba42210350e10ce) | [PR-1](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/1) | [TC-016](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/92?rev=1) | test case: [TC-016](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/92?rev=1); result: [RES-2-016](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/16); outcome: Passed | 
| [SRS-017](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/38?rev=1) | 1 | [COMP-01@b128b9c4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-ui_confirm@4a6745ab](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_confirm.py&version=GC19a676f57c68051681fbb502cba42210350e10ce) | [PR-1](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/1) | [TC-017](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/93?rev=1) | test case: [TC-017](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/93?rev=1); result: [RES-2-017](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/17); outcome: Passed | 
| [SRS-018](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/39?rev=1) | 1 | [COMP-05@17b6bad7](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-drug_limits@e7d7f0a4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GCe76df834d4f13b26458559daf65c894d6d59f7ba) | [PR-5](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/5) | [TC-018](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/94?rev=1) | test case: [TC-018](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/94?rev=1); result: [RES-2-018](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/18); outcome: Passed | 
| [SRS-019](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/40?rev=1) | 1 | [COMP-05@17b6bad7](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-drug_lookup@9b215c47](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GCe76df834d4f13b26458559daf65c894d6d59f7ba) | [PR-5](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/5) | [TC-019](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/95?rev=1) | test case: [TC-019](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/95?rev=1); result: [RES-2-019](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/19); outcome: Passed | 
| [SRS-020](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/41?rev=1) | 1 | [COMP-05@17b6bad7](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-drug_lookup@9b215c47](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GCe76df834d4f13b26458559daf65c894d6d59f7ba) | [PR-5](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/5) | [TC-020](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/96?rev=1) | test case: [TC-020](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/96?rev=1); result: [RES-2-020](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/20); outcome: Passed | 
| [SRS-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/42?rev=2) | 2 | [COMP-03@9ae26fe4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-sensor_pressure@a1d3651b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GCb0036579f0c7a3689c502323bca2f9f6b8057806) | [PR-3](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/3)<br>[PR-8](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/8) | [TC-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/97?rev=1) | test case: [TC-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/97?rev=1); result: [RES-3-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/3/results/21); outcome: Failed | 
| [SRS-022](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/43?rev=1) | 1 | [COMP-03@9ae26fe4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-sensor_filter@8b9b8bc9](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC7a0e2fbd85d24478ad55231b8952528126fcfd9b) | [PR-3](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/3) | [TC-022](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/98?rev=1) | test case: [TC-022](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/98?rev=1); result: [RES-2-022](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/22); outcome: Passed | 
| [SRS-023](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | 1 | [COMP-03@9ae26fe4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-sensor_calibration@605da84b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC7a0e2fbd85d24478ad55231b8952528126fcfd9b) | [PR-3](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/3) | [TC-023](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/99?rev=1) | test case: [TC-023](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/99?rev=1); result: [RES-2-023](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/23); outcome: Passed | 
| [SRS-024](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/45?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-log_events@92fbf9b0](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GC2b2f6cfeb1a806bfadf816e7f62a82a0db39b559) | [PR-6](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/6) | [TC-024](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/100?rev=1) | test case: [TC-024](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/100?rev=1); result: [RES-2-024](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/24); outcome: Passed | 
| [SRS-025](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/46?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-log_digest@ab99e552](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GC2b2f6cfeb1a806bfadf816e7f62a82a0db39b559) | [PR-6](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/6) | [TC-025](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/101?rev=1) | test case: [TC-025](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/101?rev=1); result: [RES-2-025](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/25); outcome: Passed | 
| [SRS-026](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/47?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-comms_frame@73b95536](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GC2b2f6cfeb1a806bfadf816e7f62a82a0db39b559) | [PR-6](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/6) | [TC-026](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/102?rev=1) | test case: [TC-026](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/102?rev=1); result: [RES-2-026](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/26); outcome: Passed | 
| [SRS-027](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/48?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-comms_timeout@9f794d28](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GC2b2f6cfeb1a806bfadf816e7f62a82a0db39b559) | [PR-6](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/6) | [TC-027](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/103?rev=1) | test case: [TC-027](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/103?rev=1); result: [RES-2-027](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/27); outcome: Passed | 
| [SRS-028](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/49?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-infusion_volume@0b716c6e](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCd5ed9fe298cdc7b6f1c65e14a172069ca3abf5b5) | [PR-2](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/2) | [TC-028](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/104?rev=1) | test case: [TC-028](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/104?rev=1); result: [RES-2-028](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/28); outcome: Passed | 
| [SRS-029](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/50?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-comms_timeout@9f794d28](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GC2b2f6cfeb1a806bfadf816e7f62a82a0db39b559) | [PR-6](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/6) | [TC-029](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/105?rev=1) | test case: [TC-029](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/105?rev=1); result: [RES-2-029](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/29); outcome: Passed | 
| [SRS-030](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/51?rev=2) | 2 | [COMP-02@d5c8005b](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCd5ed9fe298cdc7b6f1c65e14a172069ca3abf5b5) | [PR-2](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/2) | [TC-030](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/106?rev=1) | test case: [TC-030](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/106?rev=1); result: [RES-2-030](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/30); outcome: Passed | 
| [SRS-031](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/52?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-log_events@92fbf9b0](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GC2b2f6cfeb1a806bfadf816e7f62a82a0db39b559) | [PR-6](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/6) | [TC-031](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/107?rev=1) | test case: [TC-031](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/107?rev=1); result: [RES-2-031](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/31); outcome: Passed | 
| [SRS-032](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/53?rev=1) | 1 | [COMP-01@b128b9c4](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-ui_status@4d866549](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_status.py&version=GC19a676f57c68051681fbb502cba42210350e10ce) | [PR-1](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/1) | — | — | 
| [SRS-033](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/54?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [UNIT-log_events@92fbf9b0](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GC2b2f6cfeb1a806bfadf816e7f62a82a0db39b559) | [PR-6](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/6) | [TC-032](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/108?rev=1) | test case: [TC-032](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/108?rev=1); result: [RES-2-032](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/32); outcome: Passed | 
| [SRS-034](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/55?rev=1) | 1 | [COMP-04@eec25a71](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | — | — | — | — | 
| [SRS-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | 1 | [COMP-05@17b6bad7](http://127.0.0.1:53994/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | — | — | — | — | 


<!-- endsection:results_by_requirement -->

<!-- section:anomaly_assessment -->
## Failed tests and anomaly assessment

| Result | Test case | Outcome | Requirements | Linked defect | 
| --- | --- | --- | --- | --- | 
| [RES-2-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/8) | [TC-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/84?rev=1) | Failed | [SRS-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/29?rev=1) | [BUG-01](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/117?rev=1) | 
| [RES-3-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/3/results/21) | [TC-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/97?rev=1) | Failed | [SRS-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/42?rev=2) | none — see G05 | 

<!-- dhf-claim:6aab35c532437e98 -->
RES-2-008 records failed execution of TC-008. [RES-2-008@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/8) [TC-008@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/84?rev=1)

<!-- dhf-claim:912439658e9990e2 -->
RES-3-021 records failed execution of TC-021. [RES-3-021@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/3/results/21) [TC-021@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/97?rev=1)


<!-- endsection:anomaly_assessment -->

<!-- section:retest_results -->
## Retest results

| Test case | Latest result | Outcome | 
| --- | --- | --- | 
| [TC-001](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/77?rev=1) | [RES-2-001](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/1) | Passed | 
| [TC-002](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/78?rev=1) | [RES-2-002](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/2) | Passed | 
| [TC-003](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/79?rev=1) | [RES-2-003](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/3) | Passed | 
| [TC-004](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/80?rev=1) | [RES-2-004](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/4) | Passed | 
| [TC-005](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/81?rev=1) | [RES-2-005](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/5) | Passed | 
| [TC-006](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/82?rev=1) | [RES-2-006](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/6) | Passed | 
| [TC-007](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/83?rev=1) | [RES-2-007](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/7) | Passed | 
| [TC-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/84?rev=1) | [RES-2-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/8) | Failed | 
| [TC-009](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/85?rev=1) | [RES-2-009](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/9) | Passed | 
| [TC-010](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/86?rev=1) | [RES-2-010](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/10) | Passed | 
| [TC-011](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/87?rev=1) | [RES-2-011](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/11) | Passed | 
| [TC-012](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/88?rev=1) | [RES-2-012](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/12) | Passed | 
| [TC-013](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/89?rev=1) | [RES-2-013](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/13) | Passed | 
| [TC-014](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/90?rev=1) | [RES-2-014](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/14) | Passed | 
| [TC-015](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/91?rev=1) | [RES-2-015](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/15) | Passed | 
| [TC-016](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/92?rev=1) | [RES-2-016](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/16) | Passed | 
| [TC-017](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/93?rev=1) | [RES-2-017](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/17) | Passed | 
| [TC-018](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/94?rev=1) | [RES-2-018](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/18) | Passed | 
| [TC-019](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/95?rev=1) | [RES-2-019](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/19) | Passed | 
| [TC-020](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/96?rev=1) | [RES-2-020](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/20) | Passed | 
| [TC-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/97?rev=1) | [RES-3-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/3/results/21) | Failed | 
| [TC-022](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/98?rev=1) | [RES-2-022](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/22) | Passed | 
| [TC-023](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/99?rev=1) | [RES-2-023](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/23) | Passed | 
| [TC-024](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/100?rev=1) | [RES-2-024](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/24) | Passed | 
| [TC-025](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/101?rev=1) | [RES-2-025](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/25) | Passed | 
| [TC-026](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/102?rev=1) | [RES-2-026](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/26) | Passed | 
| [TC-027](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/103?rev=1) | [RES-2-027](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/27) | Passed | 
| [TC-028](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/104?rev=1) | [RES-2-028](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/28) | Passed | 
| [TC-029](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/105?rev=1) | [RES-2-029](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/29) | Passed | 
| [TC-030](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/106?rev=1) | [RES-2-030](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/30) | Passed | 
| [TC-031](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/107?rev=1) | [RES-2-031](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/31) | Passed | 
| [TC-032](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/108?rev=1) | [RES-2-032](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/32) | Passed | 
| [TC-033](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/109?rev=1) | [RES-2-033](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/33) | Passed | 
| [TC-034](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/110?rev=1) | [RES-2-034](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/34) | Passed | 
| [TC-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/111?rev=1) | [RES-2-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/35) | Passed | 
| [TC-036](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/112?rev=1) | [RES-2-036](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/36) | Passed | 
| [TC-037](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/113?rev=1) | [RES-2-037](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/37) | Passed | 
| [TC-038](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/114?rev=1) | [RES-2-038](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/38) | Passed | 
| [TC-039](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/115?rev=1) | [RES-2-039](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/39) | Passed | 
| [TC-040](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/116?rev=1) | [RES-2-040](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/40) | Passed | 


<!-- endsection:retest_results -->

<!-- section:residual_anomalies -->
## Known residual anomalies

<!-- dhf-claim:e9af4259dcba3bc5 -->
A transient high air reading is detected but the critical alarm clears without acknowledgement. Unsafe-condition indication can disappear before review. Impact assessment: Operator may miss an air condition; keep synthetic bench delivery inhibited until latch verification passes. Status rationale: Follow-up review required. [BUG-01@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/117?rev=1)

<!-- dhf-claim:6f9e1393183d6f19 -->
A release 1.0 sustained-pressure trial exceeded the configured dwell at a polling boundary. Impact assessment: Possible delayed occlusion warning; release 1.1 retest passes and closes this trial-specific issue. Status rationale: Follow-up review required. [BUG-02@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/118?rev=1)

<!-- dhf-claim:214db4c37da8d35a -->
Exporting a log with equal timestamps returns records in non-stable order. Impact assessment: Audit reconstruction may be ambiguous; the export ordering issue remains under investigation. Status rationale: Follow-up review required. [BUG-03@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/119?rev=1)


<!-- dhf-resolution:e9af4259dcba3bc5 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:6f9e1393183d6f19 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:214db4c37da8d35a accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:residual_anomalies -->

<!-- section:verification_gaps -->
## Verification coverage gaps

| Rule | Artifact | Rev | Finding | Recommended action | 
| --- | --- | --- | --- | --- | 
| G01 | [SRS-012](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/33?rev=1) | 1 | SRS has no verifying test | Add or link a verifying test for the requirement. | 
| G01 | [SRS-032](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/53?rev=1) | 1 | SRS has no verifying test | Add or link a verifying test for the requirement. | 
| G01 | [SRS-034](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/55?rev=1) | 1 | SRS has no verifying test | Add or link a verifying test for the requirement. | 
| G01 | [SRS-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | 1 | SRS has no verifying test | Add or link a verifying test for the requirement. | 
| G02 | [SRS-034](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/55?rev=1) | 1 | SRS has no implementing change | Link an implementing change or record a justified implementation gap. | 
| G02 | [SRS-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | 1 | SRS has no implementing change | Link an implementing change or record a justified implementation gap. | 
| G04 | [TC-040](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/116?rev=1) | 1 | Test case has no requirement | Link the test to its verified requirement or justify its standalone scope. | 
| G07 | [SRS-012](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/33?rev=1) | 1 | Risk-control requirement has no verification | Add verification evidence for the risk-control requirement. | 
| G09 | [SRS-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | 1 | SRS has no parent system requirement | Link the parent system requirement or justify the requirement origin. | 
| G11 | [TC-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/97?rev=1) | 1 | Test passed against an older requirement revision | Rerun verification against the current requirement revision. | 
| G11 | [TC-030](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/106?rev=1) | 1 | Test passed against an older requirement revision | Rerun verification against the current requirement revision. | 


<!-- endsection:verification_gaps -->

<!-- section:release_conclusion -->
## Conclusion and release readiness

<!-- dhf-claim:e9af4259dcba3bc5 -->
**[Suggested — review required]** A transient high air reading is detected but the critical alarm clears without acknowledgement. Unsafe-condition indication can disappear before review. Impact assessment: Operator may miss an air condition; keep synthetic bench delivery inhibited until latch verification passes. Status rationale: Follow-up review required. [BUG-01@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/117?rev=1)

<!-- dhf-claim:6f9e1393183d6f19 -->
**[Suggested — review required]** A release 1.0 sustained-pressure trial exceeded the configured dwell at a polling boundary. Impact assessment: Possible delayed occlusion warning; release 1.1 retest passes and closes this trial-specific issue. Status rationale: Follow-up review required. [BUG-02@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/118?rev=1)

<!-- dhf-claim:214db4c37da8d35a -->
**[Suggested — review required]** Exporting a log with equal timestamps returns records in non-stable order. Impact assessment: Audit reconstruction may be ambiguous; the export ordering issue remains under investigation. Status rationale: Follow-up review required. [BUG-03@r1](http://127.0.0.1:53994/kestrel-org/Kestrel/_workitems/edit/119?rev=1)


<!-- endsection:release_conclusion -->

<!-- section:evidence_index -->
## Evidence index

| Artifact | Rev | Content hash | 
| --- | --- | --- | 
| [RES-2-001](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/1) | 1 | 280d1975b77da39980e7aef9bd61ab819700b92497fa21cb6487de7b87193f48 | 
| [RES-2-002](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/2) | 1 | 1c45eb99f5d729a0036e2a1cbeccf0502d9b3e48c07633f56b71c4b565310cfa | 
| [RES-2-003](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/3) | 1 | 10669c5db07e63b07303b8eb3726e51ed0b052687df23b976adc9f06efd898f0 | 
| [RES-2-004](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/4) | 1 | 7a28ef7eb6c54009c157b41142a2964d2e26092e22428dd3823259fbc3afb896 | 
| [RES-2-005](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/5) | 1 | bfda22a4e6535a29d785ac53bace44d97c3fcb82dd14d4dce982414d72684cb4 | 
| [RES-2-006](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/6) | 1 | 4d9f796cf23810fac055f41735827ddc2024c3ea2db610dd241b9af583f5c606 | 
| [RES-2-007](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/7) | 1 | 80a1278230768d2462c1756c3fbecb39b201dab64b820548a72c7792f9efe504 | 
| [RES-2-008](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/8) | 1 | dd1ea4e0d32dbb46a17781145f3e3956a439abdcfda02009fa5af38c6a34eb00 | 
| [RES-2-009](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/9) | 1 | 3d6aacf7a049d119ee4243138121013253bc45f7368f803ae2ccabd36989b6f2 | 
| [RES-2-010](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/10) | 1 | 5c7323c51225d1fada30d84c82291dbbe12ca7b9fc39b0aabc97fe4edd61861c | 
| [RES-2-011](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/11) | 1 | ce81489d396ba39ebeae92953b9643d75ccd2de5d0d7f0ab6c190fb580a3fc9f | 
| [RES-2-012](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/12) | 1 | e3b83ae0d12cf04cf7fb64020ed19ccc32a6ec4348ef8b3cc7948b777b67d511 | 
| [RES-2-013](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/13) | 1 | cc1c5335f64e3447d7776e67b6de36283678fa669e4b15ead8f03b230f0caff7 | 
| [RES-2-014](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/14) | 1 | 247e3858092362dff4df47c37ddb5cfdbe8db2bc193ddf465a7a163bf906f85c | 
| [RES-2-015](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/15) | 1 | 3f57beae0981f21d4ad6912b286f9420ec2350c2ee68565036bcb86fdad4335c | 
| [RES-2-016](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/16) | 1 | 33daeeb1861366bd7ae9c5533169608c9c5bceec5b894042b9855f7727d373a2 | 
| [RES-2-017](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/17) | 1 | 108918e2c40dcd96aede078f5111e1e8f34f7af8c0281d169d01117b44ae3f49 | 
| [RES-2-018](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/18) | 1 | 7935fcca51fa6d5df982d75a899555374e91e0fef6ee1d624aea0eb10cc3ea1a | 
| [RES-2-019](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/19) | 1 | abca1e780e78f4aab054443a4a9f69579d8d76555d4f9f49775f809a7d2c1074 | 
| [RES-2-020](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/20) | 1 | bd9f7c164d972b5b7d067426e8d8367ad126f950d8232d6670181e5afc94b9b7 | 
| [RES-2-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/21) | 1 | 23352ddb02f439fd90a8e00cb0aa49e583be29d4c48e1a00527e872d01c66b33 | 
| [RES-2-022](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/22) | 1 | 5e814a74fbd6de777758187b99d8268f14f68c7205027c80d906a30b114eb478 | 
| [RES-2-023](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/23) | 1 | f4de4e6f5631ef335ff37274a2264c084eb880ca3918c0706b80743ec9253157 | 
| [RES-2-024](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/24) | 1 | 68cb264372a0cf5b8bc6162fce82aeef2ecbd10b0d17de50fd25a359e98e2828 | 
| [RES-2-025](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/25) | 1 | ad1b972a69ad1e11c217e0e232f04179b67e543ec95aecb974ac0665d99009b7 | 
| [RES-2-026](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/26) | 1 | 6a86c5856867ea6bb47abf9cced4f6779e09a9bcaaccbcefa1188a4ec4c34a38 | 
| [RES-2-027](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/27) | 1 | 2e03bbbc837c8fa54493854e30d2d13a4a35cf2409685d13a9863a96359d9cc6 | 
| [RES-2-028](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/28) | 1 | 044a6387a75269fcdcbd8643c8af3a8b35ba66dbf378800f6534b880fa0aaeb4 | 
| [RES-2-029](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/29) | 1 | 7db45ca1cde0f23d735c572d5f6c069ecb0b04850fe1ca54b99293227eee6654 | 
| [RES-2-030](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/30) | 1 | 241b5f335ee801eabadf66292b604473bcff8f0a60323ac68021882ffb737d6f | 
| [RES-2-031](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/31) | 1 | 0c5e431f56ca6e49c2aaea244f39cada7217fe59d5d4ab7bdc65528a2a9f2644 | 
| [RES-2-032](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/32) | 1 | 3b87ea027156496dda95ba8ce0f433ed482505138a426534406d86eb41d70a6a | 
| [RES-2-033](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/33) | 1 | b71507dbb423f18b196538f2d5e9c8d43c9a80b649af32072534b4351aaeb78c | 
| [RES-2-034](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/34) | 1 | f3ba89977c402ce4c1f5274800738cefce776e8c6c6fbc1c4641db496050db09 | 
| [RES-2-035](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/35) | 1 | 5718de15c00e660d4c7515d40a5826a9db29d5b71dd041a1a8fe455a92055f18 | 
| [RES-2-036](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/36) | 1 | b2c3a4e6db50ef2d3fa0fe715f3f1cd8835efe1368e1633601ed6a8fb852dac1 | 
| [RES-2-037](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/37) | 1 | a89314e9c7ea77a88ce101a812a2aeead85a527dad00b0ac53b0419b7fd105bc | 
| [RES-2-038](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/38) | 1 | a8668f4b23ab30d7cc759462bd9f543be274763aa20a0086ebcfdf1158e8bf96 | 
| [RES-2-039](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/39) | 1 | b365009cbca335ba943f3f476bedf863045fef8d3b57306c344c9eb81aa04201 | 
| [RES-2-040](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2/results/40) | 1 | 7b79eb01128d4ce811248a227c31892c9d2dcc31b5e9aa776af698fae41467a2 | 
| [RES-3-021](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/3/results/21) | 1 | de5b5801bb5aa9a93727196df3605f755dd07a5e38b467500515792f546c2957 | 
| [RUN-2](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/2) | 1 | 2c5305e35817df78e2ae8563ffa4e2e255f8ce156411279f7af374330d254765 | 
| [RUN-3](http://127.0.0.1:53994/kestrel-org/Kestrel/_apis/test/runs/3) | 1 | 596bf62d22626a781bf1044210d24c552c54b2424ab6fc7455c62b32cd444b62 | 


<!-- endsection:evidence_index -->

<!-- section:approvals -->
## Approvals

Synthetic reviewer supplied draft content. eQMS approval remains pending.

<!-- endsection:approvals -->
