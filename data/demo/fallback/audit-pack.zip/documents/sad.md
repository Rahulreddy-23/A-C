# Software Architecture Document

<!-- section:purpose -->
## Purpose, scope and definitions

<!-- dhf-claim:ca8f9d9e337dccd4 -->
The operator needs to set and monitor infusion without relying on undocumented device state. The controller must make its current mode visible and retain objective verification evidence for later review. [UN-001@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/1?rev=1)

<!-- dhf-claim:3aa2527bfe9b9016 -->
The operator needs to limit delivered volume without relying on undocumented device state. The controller must make its current mode visible and retain objective verification evidence for later review. [UN-002@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/2?rev=1)

<!-- dhf-claim:a3e3cfd768badde6 -->
The operator needs to detect unsafe sensor conditions without relying on undocumented device state. The controller must make its current mode visible and retain objective verification evidence for later review. [UN-003@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/3?rev=1)


<!-- endsection:purpose -->

<!-- section:context -->
## System context and external interfaces

<!-- dhf-claim:955cf0c176eed1ec -->
The Kestrel controller shall provide set and monitor infusion during simulated operation. Allocate this obligation to software while keeping unsafe-condition handling independent of UI refresh. Verification uses the bench simulator and recorded run metadata. [SYS-001@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/7?rev=1)

<!-- dhf-claim:a39a6210b976d797 -->
The Kestrel controller shall provide limit delivered volume during simulated operation. Allocate this obligation to software while keeping unsafe-condition handling independent of UI refresh. Verification uses the bench simulator and recorded run metadata. [SYS-002@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/8?rev=1)

<!-- dhf-claim:2c508c01bc56d8a5 -->
The Kestrel controller shall provide detect unsafe sensor conditions during simulated operation. Allocate this obligation to software while keeping unsafe-condition handling independent of UI refresh. Verification uses the bench simulator and recorded run metadata. [SYS-003@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/9?rev=1)


<!-- endsection:context -->

<!-- section:classification -->
## Software safety classification reference

| Component | Name | Source safety class | 
| --- | --- | --- | 
| [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | UI | B | 
| [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Infusion Control | C | 
| [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Sensor Monitoring | C | 
| [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Alarm Manager | C | 
| [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Drug Library | C | 
| [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Logging & Comms | C | 


<!-- endsection:classification -->

<!-- section:architecture -->
## Component and unit allocation diagram

```mermaid
flowchart LR
  COMP_01["COMP-01: UI"]
  COMP_02["COMP-02: Infusion Control"]
  COMP_03["COMP-03: Sensor Monitoring"]
  COMP_04["COMP-04: Alarm Manager"]
  COMP_05["COMP-05: Drug Library"]
  COMP_06["COMP-06: Logging & Comms"]
  UNIT_alarm_audio["UNIT-alarm_audio: alarm_audio"]
  UNIT_alarm_latch["UNIT-alarm_latch: alarm_latch"]
  UNIT_alarm_priority["UNIT-alarm_priority: alarm_priority"]
  UNIT_comms_frame["UNIT-comms_frame: comms_frame"]
  UNIT_comms_timeout["UNIT-comms_timeout: comms_timeout"]
  UNIT_diagnostics_trace["UNIT-diagnostics_trace: diagnostics_trace"]
  UNIT_drug_limits["UNIT-drug_limits: drug_limits"]
  UNIT_drug_lookup["UNIT-drug_lookup: drug_lookup"]
  UNIT_infusion_bounds["UNIT-infusion_bounds: infusion_bounds"]
  UNIT_infusion_motor["UNIT-infusion_motor: infusion_motor"]
  UNIT_infusion_volume["UNIT-infusion_volume: infusion_volume"]
  UNIT_log_digest["UNIT-log_digest: log_digest"]
  UNIT_log_events["UNIT-log_events: log_events"]
  UNIT_sensor_air["UNIT-sensor_air: sensor_air"]
  UNIT_sensor_calibration["UNIT-sensor_calibration: sensor_calibration"]
  UNIT_sensor_filter["UNIT-sensor_filter: sensor_filter"]
  UNIT_sensor_pressure["UNIT-sensor_pressure: sensor_pressure"]
  UNIT_ui_confirm["UNIT-ui_confirm: ui_confirm"]
  UNIT_ui_input["UNIT-ui_input: ui_input"]
  UNIT_ui_status["UNIT-ui_status: ui_status"]
  UNIT_alarm_audio -->|allocated to| COMP_04
  UNIT_alarm_latch -->|allocated to| COMP_04
  UNIT_alarm_priority -->|allocated to| COMP_04
  UNIT_comms_frame -->|allocated to| COMP_06
  UNIT_comms_timeout -->|allocated to| COMP_06
  UNIT_diagnostics_trace -->|allocated to| COMP_06
  UNIT_drug_limits -->|allocated to| COMP_05
  UNIT_drug_lookup -->|allocated to| COMP_05
  UNIT_infusion_bounds -->|allocated to| COMP_02
  UNIT_infusion_motor -->|allocated to| COMP_02
  UNIT_infusion_volume -->|allocated to| COMP_02
  UNIT_log_digest -->|allocated to| COMP_06
  UNIT_log_events -->|allocated to| COMP_06
  UNIT_sensor_air -->|allocated to| COMP_03
  UNIT_sensor_calibration -->|allocated to| COMP_03
  UNIT_sensor_filter -->|allocated to| COMP_03
  UNIT_sensor_pressure -->|allocated to| COMP_03
  UNIT_ui_confirm -->|allocated to| COMP_01
  UNIT_ui_input -->|allocated to| COMP_01
  UNIT_ui_status -->|allocated to| COMP_01
  EXT_operator["operator controls / display status"]
  EXT_operator -->|declared interface| COMP_01
  EXT_samples["PressureSample / air sample"]
  EXT_samples -->|declared interface| COMP_03
  COMP_03 -->|kestrel.alarm_latch.latched| COMP_04
```


<!-- endsection:architecture -->

<!-- section:architecture_overview -->
## Architecture overview

<!-- dhf-claim:de36fa3cad21105f -->
Context: a transient unsafe condition can disappear while an operator is attending to another task. Decision: critical alarms are stateful and remain latched until acknowledgement and safe sensor state are both present. Consequences: the control path owns the latch, the UI cannot clear an active fault, and tests must cover acknowledge-while-unsafe and recovery. [ADR-01@r04071e6c](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:aeaca534feafd788 -->
Context: operator edits and recovered storage may contain partially validated settings. Decision: apply an immutable validated configuration only after all bounds and checksum checks pass. Consequences: invalid edits preserve the current configuration; restart begins inhibited and requires explicit confirmation; configuration and validation evidence are logged. [ADR-02@r4d6ae972](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)


<!-- endsection:architecture_overview -->

<!-- section:components -->
## Component responsibilities

| Component | Name | Responsibility | 
| --- | --- | --- | 
| [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | UI | Operator configuration and status | 
| [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Infusion Control | Validated delivery state and volume bounds | 
| [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Sensor Monitoring | Sample validation and occlusion/air detection | 
| [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Alarm Manager | Persistent critical alarm state | 
| [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Drug Library | Drug lookup and dose validation | 
| [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Logging & Comms | Ordered audit records and bounded communication | 


<!-- endsection:components -->

<!-- section:component_responsibility.COMP-01 -->
## COMP-01: UI

### Component design

<!-- dhf-claim:de36fa3cad21105f -->
Context: a transient unsafe condition can disappear while an operator is attending to another task. Decision: critical alarms are stateful and remain latched until acknowledgement and safe sensor state are both present. Consequences: the control path owns the latch, the UI cannot clear an active fault, and tests must cover acknowledge-while-unsafe and recovery. [ADR-01@r04071e6c](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:aeaca534feafd788 -->
Context: operator edits and recovered storage may contain partially validated settings. Decision: apply an immutable validated configuration only after all bounds and checksum checks pass. Consequences: invalid edits preserve the current configuration; restart begins inhibited and requires explicit confirmation; configuration and validation evidence are logged. [ADR-02@r4d6ae972](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)


<!-- endsection:component_responsibility.COMP-01 -->

<!-- section:component_allocation.COMP-01 -->
### Allocated requirements

| Requirement | Rev | Title | 
| --- | --- | --- | 
| [SRS-015](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/36?rev=1) | 1 | Display status | 
| [SRS-016](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/37?rev=1) | 1 | Input validation | 
| [SRS-017](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/38?rev=1) | 1 | Configuration confirmation | 
| [SRS-032](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/53?rev=1) | 1 | Residual anomaly display | 


<!-- endsection:component_allocation.COMP-01 -->

<!-- section:component_responsibility.COMP-02 -->
## COMP-02: Infusion Control

### Component design

<!-- dhf-claim:de36fa3cad21105f -->
Context: a transient unsafe condition can disappear while an operator is attending to another task. Decision: critical alarms are stateful and remain latched until acknowledgement and safe sensor state are both present. Consequences: the control path owns the latch, the UI cannot clear an active fault, and tests must cover acknowledge-while-unsafe and recovery. [ADR-01@r04071e6c](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:aeaca534feafd788 -->
Context: operator edits and recovered storage may contain partially validated settings. Decision: apply an immutable validated configuration only after all bounds and checksum checks pass. Consequences: invalid edits preserve the current configuration; restart begins inhibited and requires explicit confirmation; configuration and validation evidence are logged. [ADR-02@r4d6ae972](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:1bcb3095f54fd5dc -->
Infusion Control validates DeliveryConfiguration atomically before start, rejects configuration edits while running, and clamps each delivered increment to remaining target volume. Sensor Monitoring supplies safe/fault decisions; Alarm Manager supplies active critical latches. Faults inhibit delivery and restart requires a valid configuration. [COMP-02@rd5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)


<!-- endsection:component_responsibility.COMP-02 -->

<!-- section:component_allocation.COMP-02 -->
### Allocated requirements

| Requirement | Rev | Title | 
| --- | --- | --- | 
| [SRS-001](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/22?rev=1) | 1 | Flow bounds | 
| [SRS-002](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/23?rev=1) | 1 | Volume limit | 
| [SRS-003](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/24?rev=1) | 1 | Start interlock | 
| [SRS-004](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/25?rev=1) | 1 | Pause control | 
| [SRS-005](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/26?rev=1) | 1 | Stop control | 
| [SRS-006](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/27?rev=1) | 1 | Rate conversion | 
| [SRS-028](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/49?rev=1) | 1 | Delivery estimation | 
| [SRS-030](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/51?rev=2) | 2 | Power loss recovery | 


<!-- endsection:component_allocation.COMP-02 -->

<!-- section:component_responsibility.COMP-03 -->
## COMP-03: Sensor Monitoring

### Component design

<!-- dhf-claim:de36fa3cad21105f -->
Context: a transient unsafe condition can disappear while an operator is attending to another task. Decision: critical alarms are stateful and remain latched until acknowledgement and safe sensor state are both present. Consequences: the control path owns the latch, the UI cannot clear an active fault, and tests must cover acknowledge-while-unsafe and recovery. [ADR-01@r04071e6c](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:aeaca534feafd788 -->
Context: operator edits and recovered storage may contain partially validated settings. Decision: apply an immutable validated configuration only after all bounds and checksum checks pass. Consequences: invalid edits preserve the current configuration; restart begins inhibited and requires explicit confirmation; configuration and validation evidence are logged. [ADR-02@r4d6ae972](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)


<!-- endsection:component_responsibility.COMP-03 -->

<!-- section:component_allocation.COMP-03 -->
### Allocated requirements

| Requirement | Rev | Title | 
| --- | --- | --- | 
| [SRS-008](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/29?rev=1) | 1 | Air detection | 
| [SRS-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/30?rev=1) | 1 | Pressure sampling | 
| [SRS-010](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/31?rev=1) | 1 | Sensor diagnostics | 
| [SRS-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/42?rev=2) | 2 | Occlusion threshold | 
| [SRS-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/43?rev=1) | 1 | Pressure filtering | 
| [SRS-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | 1 | Sensor calibration | 


<!-- endsection:component_allocation.COMP-03 -->

<!-- section:component_responsibility.COMP-04 -->
## COMP-04: Alarm Manager

### Component design

<!-- dhf-claim:de36fa3cad21105f -->
Context: a transient unsafe condition can disappear while an operator is attending to another task. Decision: critical alarms are stateful and remain latched until acknowledgement and safe sensor state are both present. Consequences: the control path owns the latch, the UI cannot clear an active fault, and tests must cover acknowledge-while-unsafe and recovery. [ADR-01@r04071e6c](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:aeaca534feafd788 -->
Context: operator edits and recovered storage may contain partially validated settings. Decision: apply an immutable validated configuration only after all bounds and checksum checks pass. Consequences: invalid edits preserve the current configuration; restart begins inhibited and requires explicit confirmation; configuration and validation evidence are logged. [ADR-02@r4d6ae972](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:869bbb860543c3e2 -->
Alarm Manager records events independently of display refresh, orders visible alarms by priority, and keeps an unsafe condition active after acknowledgement. Critical active alarms request inhibited delivery; audio and display present that latch without owning its recovery state. [COMP-04@reec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)


<!-- endsection:component_responsibility.COMP-04 -->

<!-- section:component_allocation.COMP-04 -->
### Allocated requirements

| Requirement | Rev | Title | 
| --- | --- | --- | 
| [SRS-011](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/32?rev=1) | 1 | Alarm priority | 
| [SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1) | 1 | Alarm latch | 
| [SRS-013](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/34?rev=1) | 1 | Alarm acknowledgement | 
| [SRS-014](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/35?rev=1) | 1 | Audible alarm | 
| [SRS-034](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/55?rev=1) | 1 | Service access policy | 


<!-- endsection:component_allocation.COMP-04 -->

<!-- section:component_responsibility.COMP-05 -->
## COMP-05: Drug Library

### Component design

<!-- dhf-claim:de36fa3cad21105f -->
Context: a transient unsafe condition can disappear while an operator is attending to another task. Decision: critical alarms are stateful and remain latched until acknowledgement and safe sensor state are both present. Consequences: the control path owns the latch, the UI cannot clear an active fault, and tests must cover acknowledge-while-unsafe and recovery. [ADR-01@r04071e6c](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:aeaca534feafd788 -->
Context: operator edits and recovered storage may contain partially validated settings. Decision: apply an immutable validated configuration only after all bounds and checksum checks pass. Consequences: invalid edits preserve the current configuration; restart begins inhibited and requires explicit confirmation; configuration and validation evidence are logged. [ADR-02@r4d6ae972](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ed9196ec5c14072a -->
Drug Library resolves stable record keys and validates dose/rate against configured bounds before activation. Invalid values and missing records prevent configuration acceptance. Its validated limits support Infusion Control and are presented through operator configuration. [COMP-05@r17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)


<!-- endsection:component_responsibility.COMP-05 -->

<!-- section:component_allocation.COMP-05 -->
### Allocated requirements

| Requirement | Rev | Title | 
| --- | --- | --- | 
| [SRS-007](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/28?rev=1) | 1 | Dose calculation | 
| [SRS-018](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/39?rev=1) | 1 | Drug limit validation | 
| [SRS-019](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/40?rev=1) | 1 | Drug lookup | 
| [SRS-020](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/41?rev=1) | 1 | Library checksum | 
| [SRS-035](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | 1 | Localization selection | 


<!-- endsection:component_allocation.COMP-05 -->

<!-- section:component_responsibility.COMP-06 -->
## COMP-06: Logging & Comms

### Component design

<!-- dhf-claim:de36fa3cad21105f -->
Context: a transient unsafe condition can disappear while an operator is attending to another task. Decision: critical alarms are stateful and remain latched until acknowledgement and safe sensor state are both present. Consequences: the control path owns the latch, the UI cannot clear an active fault, and tests must cover acknowledge-while-unsafe and recovery. [ADR-01@r04071e6c](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:aeaca534feafd788 -->
Context: operator edits and recovered storage may contain partially validated settings. Decision: apply an immutable validated configuration only after all bounds and checksum checks pass. Consequences: invalid edits preserve the current configuration; restart begins inhibited and requires explicit confirmation; configuration and validation evidence are logged. [ADR-02@r4d6ae972](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)


<!-- endsection:component_responsibility.COMP-06 -->

<!-- section:component_allocation.COMP-06 -->
### Allocated requirements

| Requirement | Rev | Title | 
| --- | --- | --- | 
| [SRS-024](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/45?rev=1) | 1 | Event persistence | 
| [SRS-025](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/46?rev=1) | 1 | Log integrity | 
| [SRS-026](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/47?rev=1) | 1 | Communication framing | 
| [SRS-027](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/48?rev=1) | 1 | Communication timeout | 
| [SRS-029](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/50?rev=1) | 1 | Watchdog | 
| [SRS-031](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/52?rev=1) | 1 | Time validation | 
| [SRS-033](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/54?rev=1) | 1 | Export audit records | 


<!-- endsection:component_allocation.COMP-06 -->

<!-- section:interfaces -->
## Extracted internal interfaces

| Unit | Component | Signatures | 
| --- | --- | --- | 
| [UNIT-alarm_audio@220f842d](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def audible(critical: bool, muted: bool) -> bool<br>def __init__(self, interval_s: float, maximum_mute_s: float) -> None<br>def mute(self, now: float, requested_s: float) -> None<br>def tick(self, now: float, critical: bool) -> bool | 
| [UNIT-alarm_latch@b36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def latched(active: bool, acknowledged: bool, unsafe: bool) -> bool<br>def __init__(self) -> None<br>def update(self, code: str, priority: Priority, unsafe: bool) -> AlarmState<br>def acknowledge(self, code: str) -> bool<br>def stop_required(self) -> bool<br>def visible(self) -> list[AlarmState] | 
| [UNIT-alarm_priority@f71bb757](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def highest(alarms: list[dict]) -> dict \| None<br>def __init__(self) -> None<br>def update(self, code: str, priority: int, active: bool) -> None<br>def select(self) -> dict \| None<br>def clear_inactive(self) -> None<br>def snapshot(self) -> list[dict]<br>def active_count(self) -> int | 
| [UNIT-comms_frame@73b95536](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def valid_frame(payload: bytes) -> bool<br>def __init__(self, maximum_bytes: int=1024) -> None<br>def append(self, chunk: bytes) -> list[bytes]<br>def reset(self) -> None | 
| [UNIT-comms_timeout@9f794d28](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def overdue(now: float, last: float, timeout: float) -> bool<br>def __init__(self, timeout_s: float) -> None<br>def response(self, now: float) -> None<br>def poll(self, now: float) -> bool<br>def snapshot(self) -> dict | 
| [UNIT-diagnostics_trace@0e543199](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GCc97b66528e09945be2a3fc3d2934dcdaaca42be7) | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def diagnostic_summary(values: list[float]) -> dict | 
| [UNIT-drug_limits@e7d7f0a4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) | [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def valid_dose(dose: float, minimum: float, maximum: float) -> bool<br>def validate(self) -> None<br>def __init__(self, limits: DrugLimits)<br>def volume_for(self, dose: float) -> float<br>def check_proposal(self, proposal: dict) -> dict | 
| [UNIT-drug_lookup@9b215c47](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) | [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def lookup(library: dict, key: str) -> dict<br>def __init__(self, records: dict) -> None<br>def get(self, key: str) -> dict<br>def keys(self) -> list[str]<br>def select(self, key: str, dose: float) -> dict | 
| [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def within_bounds(rate: float, minimum: float, maximum: float) -> bool<br>def validate(self) -> None<br>def __init__(self) -> None<br>def configure(self, proposed: DeliveryConfiguration) -> None<br>def start(self, sensor_safe: bool, alarm_active: bool) -> None<br>def tick(self, elapsed_s: float, sensor_safe: bool) -> float<br>def pause(self) -> None<br>def stop(self) -> None | 
| [UNIT-infusion_motor@eb1bd363](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def pulse_interval(rate: float, pulses_per_ml: int) -> float<br>def __init__(self, pulses_per_ml: int) -> None<br>def configure(self, rate: float) -> None<br>def pulses(self, elapsed_s: float, enabled: bool) -> int | 
| [UNIT-infusion_volume@0b716c6e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def target_reached(delivered: float, target: float) -> bool<br>def __init__(self, target: float) -> None<br>def add(self, requested: float) -> float<br>def stop(self) -> None<br>def snapshot(self) -> dict | 
| [UNIT-log_digest@ab99e552](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def digest(payload: bytes) -> str<br>def __init__(self, payload: bytes) -> None<br>def verify(self, candidate: bytes) -> bool<br>def describe(self) -> dict<br>def require_valid(self, candidate: bytes) -> None | 
| [UNIT-log_events@92fbf9b0](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def append_event(events: list[dict], event: dict) -> list[dict]<br>def __init__(self) -> None<br>def record(self, event: AuditEvent) -> None<br>def export(self) -> list[dict]<br>def content_digest(self) -> str | 
| [UNIT-sensor_air@f8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def air_detected(reading: float, limit: float) -> bool<br>def __init__(self, limit: float)<br>def evaluate(self, reading: float \| None, connected: bool=True) -> AirDecision<br>def acknowledge(self, reading: float, connected: bool=True) -> bool | 
| [UNIT-sensor_calibration@605da84b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def calibrated(reading: float, offset: float) -> float<br>def __init__(self, gain: float=1.0, offset: float=0.0) -> None<br>def apply(self, reading: float) -> float<br>def update(self, gain: float, offset: float, authorized: bool) -> None<br>def snapshot(self) -> dict | 
| [UNIT-sensor_filter@8b9b8bc9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def average(samples: list[float]) -> float<br>def __init__(self, size: int)<br>def append(self, value: float) -> float<br>def reset(self) -> None<br>def snapshot(self) -> dict | 
| [UNIT-sensor_pressure@a1d3651b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC54a17a8b49227a82c3749ac902cb3af4f907b2d2) | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def occluded(pressure: float, threshold: float=75.0) -> bool<br>def pressure_alarm(decision: PressureDecision, active: bool, acknowledged: bool) -> bool<br>def __init__(self, threshold_kpa: float=75.0, dwell_s: float=3.0)<br>def evaluate(self, sample: PressureSample \| None) -> PressureDecision<br>def acknowledge(self, sample: PressureSample) -> bool | 
| [UNIT-ui_confirm@4a6745ab](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_confirm.py&version=GC9a5adaf3b72e4a7563cc55ae3362488dad220bea) | [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def confirm(current: dict, proposed: dict, accepted: bool) -> dict | 
| [UNIT-ui_input@2e563f7b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_input.py&version=GC9a5adaf3b72e4a7563cc55ae3362488dad220bea) | [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def parse_rate(value: str, maximum: float) -> float | 
| [UNIT-ui_status@4d866549](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_status.py&version=GC9a5adaf3b72e4a7563cc55ae3362488dad220bea) | [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | def status(mode: str, volume: float) -> dict | 


<!-- endsection:interfaces -->

<!-- section:interface_context -->
## Interface context

<!-- dhf-claim:955cf0c176eed1ec -->
The Kestrel controller shall provide set and monitor infusion during simulated operation. Allocate this obligation to software while keeping unsafe-condition handling independent of UI refresh. Verification uses the bench simulator and recorded run metadata. [SYS-001@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/7?rev=1)

<!-- dhf-claim:a39a6210b976d797 -->
The Kestrel controller shall provide limit delivered volume during simulated operation. Allocate this obligation to software while keeping unsafe-condition handling independent of UI refresh. Verification uses the bench simulator and recorded run metadata. [SYS-002@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/8?rev=1)

<!-- dhf-claim:2c508c01bc56d8a5 -->
The Kestrel controller shall provide detect unsafe sensor conditions during simulated operation. Allocate this obligation to software while keeping unsafe-condition handling independent of UI refresh. Verification uses the bench simulator and recorded run metadata. [SYS-003@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/9?rev=1)


<!-- endsection:interface_context -->

<!-- section:soup -->
## SOUP inventory

| SOUP | Name | Pinned version | Recorded requirements | 
| --- | --- | --- | --- | 
| [SOUP-01@39d9f63e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | attrs | 24.2.0 | — | 
| [SOUP-02@cf7f5c7e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | cattrs | 24.1.2 | — | 
| [SOUP-03@6881c742](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | crcmod | 1.7 | — | 
| [SOUP-04@d50d45ce](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | pyserial | 3.5 | — | 
| [SOUP-05@dc66ace9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | packaging | 24.1 | — | 


<!-- endsection:soup -->

<!-- section:soup_purpose -->
## SOUP purpose and constraints

<!-- dhf-claim:b5071534728c5d4d -->
attrs [SOUP-01@r39d9f63e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt)

<!-- dhf-claim:3a47eef8f21a44a8 -->
cattrs [SOUP-02@rcf7f5c7e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt)

<!-- dhf-claim:78797959356460bd -->
crcmod [SOUP-03@r6881c742](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt)


<!-- endsection:soup_purpose -->

<!-- section:runtime -->
## Runtime and deployment view

<!-- dhf-claim:de36fa3cad21105f -->
Context: a transient unsafe condition can disappear while an operator is attending to another task. Decision: critical alarms are stateful and remain latched until acknowledgement and safe sensor state are both present. Consequences: the control path owns the latch, the UI cannot clear an active fault, and tests must cover acknowledge-while-unsafe and recovery. [ADR-01@r04071e6c](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:aeaca534feafd788 -->
Context: operator edits and recovered storage may contain partially validated settings. Decision: apply an immutable validated configuration only after all bounds and checksum checks pass. Consequences: invalid edits preserve the current configuration; restart begins inhibited and requires explicit confirmation; configuration and validation evidence are logged. [ADR-02@r4d6ae972](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)


<!-- endsection:runtime -->

<!-- section:risk_controls -->
## Architectural risk-control measures

| Hazard | Name | Source severity | Existing controls and names | 
| --- | --- | --- | --- | 
| [HAZ-01](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) | Over infusion | 5 | id: [RC-01](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/65?rev=1); title: Bounded infusion rate and delivered volume<br>id: [RC-11](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/75?rev=1); title: Safe confirmation of therapy configuration | 
| [HAZ-02](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) | Under infusion | 4 | id: [RC-02](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/66?rev=1); title: Calibrated pulse scheduling and air-in-line inhibition | 
| [HAZ-03](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) | Air delivery | 5 | id: [RC-03](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/67?rev=1); title: Air-in-line detection and inhibited delivery<br>id: [RC-10](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/74?rev=1); title: Retained disconnected-sensor fault | 
| [HAZ-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) | Undetected occlusion | 4 | id: [RC-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/68?rev=1); title: Sustained-pressure occlusion detection with latched critical alarm<br>id: [RC-09](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/73?rev=1); title: Validated pressure samples and calibration<br>id: [RC-12](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/76?rev=1); title: Independent pressure-channel plausibility cross-check | 
| [HAZ-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) | Alarm unavailable | 5 | id: [RC-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/69?rev=1); title: Prioritised latched audible alarms and safe acknowledgement | 
| [HAZ-06](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) | Incorrect drug limit | 4 | id: [RC-06](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/70?rev=1); title: Validated drug limits, lookup and library integrity | 
| [HAZ-07](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) | Lost audit evidence | 3 | id: [RC-07](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/71?rev=1); title: Ordered tamper-evident audit recording and export | 
| [HAZ-08](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) | Unintended restart | 5 | id: [RC-08](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/72?rev=1); title: Watchdog inhibition and validated power-loss recovery | 


<!-- endsection:risk_controls -->

<!-- section:allocation_matrix -->
## Requirements-to-architecture matrix

| Requirement | Rev | Components | 
| --- | --- | --- | 
| [SRS-001](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/22?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-002](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/23?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-003](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/24?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-004](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/25?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-005](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/26?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-006](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/27?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-007](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/28?rev=1) | 1 | [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-008](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/29?rev=1) | 1 | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/30?rev=1) | 1 | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-010](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/31?rev=1) | 1 | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-011](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/32?rev=1) | 1 | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1) | 1 | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-013](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/34?rev=1) | 1 | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-014](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/35?rev=1) | 1 | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-015](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/36?rev=1) | 1 | [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-016](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/37?rev=1) | 1 | [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-017](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/38?rev=1) | 1 | [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-018](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/39?rev=1) | 1 | [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-019](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/40?rev=1) | 1 | [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-020](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/41?rev=1) | 1 | [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/42?rev=2) | 2 | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/43?rev=1) | 1 | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | 1 | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-024](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/45?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-025](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/46?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-026](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/47?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-027](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/48?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-028](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/49?rev=1) | 1 | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-029](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/50?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-030](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/51?rev=2) | 2 | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-031](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/52?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-032](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/53?rev=1) | 1 | [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-033](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/54?rev=1) | 1 | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-034](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/55?rev=1) | 1 | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 
| [SRS-035](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | 1 | [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | 


<!-- endsection:allocation_matrix -->

<!-- section:decisions -->
## Architectural decisions

| Decision record | Source decision | 
| --- | --- | 
| [ADR-01@04071e6c](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Context: a transient unsafe condition can disappear while an operator is attending to another task. Decision: critical alarms are stateful and remain latched until acknowledgement and safe sensor state are both present. Consequences: the control path owns the latch, the UI cannot clear an active fault, and tests must cover acknowledge-while-unsafe and recovery. | 
| [ADR-02@4d6ae972](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Context: operator edits and recovered storage may contain partially validated settings. Decision: apply an immutable validated configuration only after all bounds and checksum checks pass. Consequences: invalid edits preserve the current configuration; restart begins inhibited and requires explicit confirmation; configuration and validation evidence are logged. | 


<!-- endsection:decisions -->

<!-- section:gaps -->
## Open design and verification gaps

| Rule | Artifact | Finding | Action | 
| --- | --- | --- | --- | 
| G01 | [SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1) | SRS has no verifying test | Add or link a verifying test for the requirement. | 
| G01 | [SRS-032](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/53?rev=1) | SRS has no verifying test | Add or link a verifying test for the requirement. | 
| G01 | [SRS-034](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/55?rev=1) | SRS has no verifying test | Add or link a verifying test for the requirement. | 
| G01 | [SRS-035](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | SRS has no verifying test | Add or link a verifying test for the requirement. | 
| G02 | [SRS-034](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/55?rev=1) | SRS has no implementing change | Link an implementing change or record a justified implementation gap. | 
| G02 | [SRS-035](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | SRS has no implementing change | Link an implementing change or record a justified implementation gap. | 
| G03 | [PR-7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/7) | Orphan code or PR | Link existing requirements or propose a requirement for human review. | 
| G03 | [UNIT-diagnostics_trace@0e543199](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GCc97b66528e09945be2a3fc3d2934dcdaaca42be7) | Orphan code or PR | Link existing requirements or propose a requirement for human review. | 
| G04 | [TC-040](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/116?rev=1) | Test case has no requirement | Link the test to its verified requirement or justify its standalone scope. | 
| G05 | [RES-1-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_apis/test/runs/1/results/21) | Failed result has no defect | Raise or link a defect for the failed result, or record a justified anomaly assessment. | 
| G05 | [RES-3-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_apis/test/runs/3/results/21) | Failed result has no defect | Raise or link a defect for the failed result, or record a justified anomaly assessment. | 
| G06 | [RC-12](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/76?rev=1) | Risk control has no realizing requirement | Trace the risk control to its realizing requirement. | 
| G07 | [SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1) | Risk-control requirement has no verification | Add verification evidence for the risk-control requirement. | 
| G08 | [SYS-015](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/21?rev=1) | System requirement has no derived SRS | Derive software requirements or justify non-software realization. | 
| G09 | [SRS-035](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | SRS has no parent system requirement | Link the parent system requirement or justify the requirement origin. | 
| G10 | [BUG-03](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/119?rev=1) | Open defect omitted from residual anomalies | Include the open defect in residual anomalies with human-reviewed rationale. | 
| G11 | [TC-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/97?rev=1) | Test passed against an older requirement revision | Rerun verification against the current requirement revision. | 
| G11 | [TC-030](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/106?rev=1) | Test passed against an older requirement revision | Rerun verification against the current requirement revision. | 
| G12 | [SOUP-01@39d9f63e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | SOUP requirements or known-anomaly evaluation not recorded | Record SOUP functional/performance requirements and evaluate its known anomaly list. | 
| G12 | [SOUP-02@cf7f5c7e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | SOUP requirements or known-anomaly evaluation not recorded | Record SOUP functional/performance requirements and evaluate its known anomaly list. | 
| G12 | [SOUP-03@6881c742](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | SOUP requirements or known-anomaly evaluation not recorded | Record SOUP functional/performance requirements and evaluate its known anomaly list. | 
| G12 | [SOUP-04@d50d45ce](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | SOUP requirements or known-anomaly evaluation not recorded | Record SOUP functional/performance requirements and evaluate its known anomaly list. | 
| G12 | [SOUP-05@dc66ace9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | SOUP requirements or known-anomaly evaluation not recorded | Record SOUP functional/performance requirements and evaluate its known anomaly list. | 


<!-- endsection:gaps -->

<!-- section:open_issues -->
## Additional open issues and dispositions

Synthetic reviewer supplied draft content. eQMS approval remains pending.

<!-- endsection:open_issues -->
