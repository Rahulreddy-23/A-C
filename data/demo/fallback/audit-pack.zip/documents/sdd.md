# Software Design Description

<!-- section:conventions -->
## Design conventions

<!-- dhf-claim:de36fa3cad21105f -->
Context: a transient unsafe condition can disappear while an operator is attending to another task. Decision: critical alarms are stateful and remain latched until acknowledgement and safe sensor state are both present. Consequences: the control path owns the latch, the UI cannot clear an active fault, and tests must cover acknowledge-while-unsafe and recovery. [ADR-01@r04071e6c](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:aeaca534feafd788 -->
Context: operator edits and recovered storage may contain partially validated settings. Decision: apply an immutable validated configuration only after all bounds and checksum checks pass. Consequences: invalid edits preserve the current configuration; restart begins inhibited and requires explicit confirmation; configuration and validation evidence are logged. [ADR-02@r4d6ae972](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)


<!-- endsection:conventions -->

<!-- section:unit_trace -->
## Software unit traceability

| Unit | Component | Requirements | 
| --- | --- | --- | 
| [UNIT-alarm_audio@220f842d](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676) | [COMP-04@eec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-014](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/35?rev=1) | 
| [UNIT-alarm_latch@b36fa4fc](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676) | [COMP-04@eec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-012](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/33?rev=1)<br>[SRS-013](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/34?rev=1) | 
| [UNIT-alarm_priority@f71bb757](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676) | [COMP-04@eec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-011](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/32?rev=1) | 
| [UNIT-comms_frame@73b95536](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0) | [COMP-06@c50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-026](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/47?rev=1) | 
| [UNIT-comms_timeout@9f794d28](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0) | [COMP-06@c50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-027](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/48?rev=1)<br>[SRS-029](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/50?rev=1) | 
| [UNIT-diagnostics_trace@0e543199](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GC5a164f4aad86960f67905d3e6bdebbe615244931) | [COMP-06@c50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | — | 
| [UNIT-drug_limits@e7d7f0a4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GCc032720ec90c44ee6a301edc34e4433eda0523b8) | [COMP-05@17b6bad7](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-007](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/28?rev=1)<br>[SRS-018](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/39?rev=1) | 
| [UNIT-drug_lookup@9b215c47](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GCc032720ec90c44ee6a301edc34e4433eda0523b8) | [COMP-05@17b6bad7](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-019](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/40?rev=1)<br>[SRS-020](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/41?rev=1) | 
| [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCfdf6de366e5cbe8be52996ded854b8a1ba25befc) | [COMP-02@d5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-001](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/22?rev=1)<br>[SRS-003](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/24?rev=1)<br>[SRS-004](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/25?rev=1)<br>[SRS-005](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/26?rev=1)<br>[SRS-030](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/51?rev=2) | 
| [UNIT-infusion_motor@eb1bd363](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCfdf6de366e5cbe8be52996ded854b8a1ba25befc) | [COMP-02@d5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-006](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/27?rev=1) | 
| [UNIT-infusion_volume@0b716c6e](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCfdf6de366e5cbe8be52996ded854b8a1ba25befc) | [COMP-02@d5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-002](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/23?rev=1)<br>[SRS-028](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/49?rev=1) | 
| [UNIT-log_digest@ab99e552](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0) | [COMP-06@c50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-025](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/46?rev=1) | 
| [UNIT-log_events@92fbf9b0](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0) | [COMP-06@c50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-024](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/45?rev=1)<br>[SRS-031](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/52?rev=1)<br>[SRS-033](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/54?rev=1) | 
| [UNIT-sensor_air@f8cd0f72](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0) | [COMP-03@9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-008](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/29?rev=1)<br>[SRS-010](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/31?rev=1) | 
| [UNIT-sensor_calibration@605da84b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0) | [COMP-03@9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-023](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | 
| [UNIT-sensor_filter@8b9b8bc9](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0) | [COMP-03@9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-022](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/43?rev=1) | 
| [UNIT-sensor_pressure@a1d3651b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC482be50e10c98d350b31ed735bc32d68e284de91) | [COMP-03@9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-009](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/30?rev=1)<br>[SRS-021](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/42?rev=2) | 
| [UNIT-ui_confirm@4a6745ab](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_confirm.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13) | [COMP-01@b128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-017](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/38?rev=1) | 
| [UNIT-ui_input@2e563f7b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_input.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13) | [COMP-01@b128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-016](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/37?rev=1) | 
| [UNIT-ui_status@4d866549](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_status.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13) | [COMP-01@b128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | [SRS-015](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/36?rev=1)<br>[SRS-032](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/53?rev=1) | 


<!-- endsection:unit_trace -->

<!-- section:identity.UNIT-alarm_audio -->
## UNIT-alarm_audio: alarm_audio

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-alarm_audio@220f842d](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676) | [COMP-04@eec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/alarm_audio.py | 


<!-- endsection:identity.UNIT-alarm_audio -->

<!-- section:purpose.UNIT-alarm_audio -->
### Purpose

<!-- dhf-claim:869bbb860543c3e2 -->
Alarm Manager records events independently of display refresh, orders visible alarms by priority, and keeps an unsafe condition active after acknowledgement. Critical active alarms request inhibited delivery; audio and display present that latch without owning its recovery state. [COMP-04@reec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:471b69bb2048b268 -->
Schedule audible alerts while critical alarms remain active. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-014@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/35?rev=1)

<!-- dhf-claim:11db9f925e5603f8 -->
alarm_audio is implemented in kestrel/alarm_audio.py. [UNIT-alarm_audio@r220f842d](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676)


<!-- endsection:purpose.UNIT-alarm_audio -->

<!-- section:interfaces.UNIT-alarm_audio -->
### Extracted interfaces

| Signature | 
| --- | 
| def audible(critical: bool, muted: bool) -> bool | 
| def __init__(self, interval_s: float, maximum_mute_s: float) -> None | 
| def mute(self, now: float, requested_s: float) -> None | 
| def tick(self, now: float, critical: bool) -> bool | 


<!-- endsection:interfaces.UNIT-alarm_audio -->

<!-- section:behavior.UNIT-alarm_audio -->
### Behavior and algorithm

<!-- dhf-claim:869bbb860543c3e2 -->
Alarm Manager records events independently of display refresh, orders visible alarms by priority, and keeps an unsafe condition active after acknowledgement. Critical active alarms request inhibited delivery; audio and display present that latch without owning its recovery state. [COMP-04@reec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:471b69bb2048b268 -->
Schedule audible alerts while critical alarms remain active. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-014@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/35?rev=1)

<!-- dhf-claim:11db9f925e5603f8 -->
alarm_audio is implemented in kestrel/alarm_audio.py. [UNIT-alarm_audio@r220f842d](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676)


<!-- endsection:behavior.UNIT-alarm_audio -->

<!-- section:structures.UNIT-alarm_audio -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| AlertScheduler | — | — | 


<!-- endsection:structures.UNIT-alarm_audio -->

<!-- section:errors.UNIT-alarm_audio -->
### Error handling

<!-- dhf-claim:869bbb860543c3e2 -->
Alarm Manager records events independently of display refresh, orders visible alarms by priority, and keeps an unsafe condition active after acknowledgement. Critical active alarms request inhibited delivery; audio and display present that latch without owning its recovery state. [COMP-04@reec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:471b69bb2048b268 -->
Schedule audible alerts while critical alarms remain active. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-014@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/35?rev=1)

<!-- dhf-claim:11db9f925e5603f8 -->
alarm_audio is implemented in kestrel/alarm_audio.py. [UNIT-alarm_audio@r220f842d](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676)


<!-- endsection:errors.UNIT-alarm_audio -->

<!-- section:allocation.UNIT-alarm_audio -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-014](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/35?rev=1) | 1 | [RC-05](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/69?rev=1) | 


<!-- endsection:allocation.UNIT-alarm_audio -->

<!-- section:tests.UNIT-alarm_audio -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-alarm_audio -->

<!-- section:identity.UNIT-alarm_latch -->
## UNIT-alarm_latch: alarm_latch

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-alarm_latch@b36fa4fc](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676) | [COMP-04@eec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/alarm_latch.py | 


<!-- endsection:identity.UNIT-alarm_latch -->

<!-- section:purpose.UNIT-alarm_latch -->
### Purpose

<!-- dhf-claim:869bbb860543c3e2 -->
Alarm Manager records events independently of display refresh, orders visible alarms by priority, and keeps an unsafe condition active after acknowledgement. Critical active alarms request inhibited delivery; audio and display present that latch without owning its recovery state. [COMP-04@reec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:d974ac1755441d00 -->
Keep critical alarms active until acknowledged safely. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-012@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/33?rev=1)

<!-- dhf-claim:ae84ced8c65d8833 -->
Record acknowledgement without clearing an active unsafe condition. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-013@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/34?rev=1)


<!-- endsection:purpose.UNIT-alarm_latch -->

<!-- section:interfaces.UNIT-alarm_latch -->
### Extracted interfaces

| Signature | 
| --- | 
| def latched(active: bool, acknowledged: bool, unsafe: bool) -> bool | 
| def __init__(self) -> None | 
| def update(self, code: str, priority: Priority, unsafe: bool) -> AlarmState | 
| def acknowledge(self, code: str) -> bool | 
| def stop_required(self) -> bool | 
| def visible(self) -> list[AlarmState] | 


<!-- endsection:interfaces.UNIT-alarm_latch -->

<!-- section:behavior.UNIT-alarm_latch -->
### Behavior and algorithm

<!-- dhf-claim:869bbb860543c3e2 -->
Alarm Manager records events independently of display refresh, orders visible alarms by priority, and keeps an unsafe condition active after acknowledgement. Critical active alarms request inhibited delivery; audio and display present that latch without owning its recovery state. [COMP-04@reec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:d974ac1755441d00 -->
Keep critical alarms active until acknowledged safely. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-012@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/33?rev=1)

<!-- dhf-claim:ae84ced8c65d8833 -->
Record acknowledgement without clearing an active unsafe condition. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-013@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/34?rev=1)


<!-- endsection:behavior.UNIT-alarm_latch -->

<!-- section:structures.UNIT-alarm_latch -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| Priority | IntEnum | ADVISORY = 1<br>WARNING = 2<br>CRITICAL = 3 | 
| AlarmState | — | code: str<br>priority: Priority<br>unsafe: bool = False<br>active: bool = False<br>acknowledged: bool = False | 
| AlarmRegistry | — | — | 


<!-- endsection:structures.UNIT-alarm_latch -->

<!-- section:errors.UNIT-alarm_latch -->
### Error handling

<!-- dhf-claim:869bbb860543c3e2 -->
Alarm Manager records events independently of display refresh, orders visible alarms by priority, and keeps an unsafe condition active after acknowledgement. Critical active alarms request inhibited delivery; audio and display present that latch without owning its recovery state. [COMP-04@reec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:d974ac1755441d00 -->
Keep critical alarms active until acknowledged safely. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-012@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/33?rev=1)

<!-- dhf-claim:ae84ced8c65d8833 -->
Record acknowledgement without clearing an active unsafe condition. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-013@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/34?rev=1)


<!-- endsection:errors.UNIT-alarm_latch -->

<!-- section:allocation.UNIT-alarm_latch -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-012](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/33?rev=1) | 1 | [RC-04](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/68?rev=1)<br>[RC-05](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/69?rev=1) | 
| [SRS-013](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/34?rev=1) | 1 | [RC-05](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/69?rev=1) | 


<!-- endsection:allocation.UNIT-alarm_latch -->

<!-- section:tests.UNIT-alarm_latch -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-alarm_latch -->

<!-- section:identity.UNIT-alarm_priority -->
## UNIT-alarm_priority: alarm_priority

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-alarm_priority@f71bb757](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676) | [COMP-04@eec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/alarm_priority.py | 


<!-- endsection:identity.UNIT-alarm_priority -->

<!-- section:purpose.UNIT-alarm_priority -->
### Purpose

<!-- dhf-claim:869bbb860543c3e2 -->
Alarm Manager records events independently of display refresh, orders visible alarms by priority, and keeps an unsafe condition active after acknowledgement. Critical active alarms request inhibited delivery; audio and display present that latch without owning its recovery state. [COMP-04@reec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:91cfb6ea771c3fbd -->
Prioritize critical faults over advisories. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-011@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/32?rev=1)

<!-- dhf-claim:2dcad8a795ad0b95 -->
alarm_priority is implemented in kestrel/alarm_priority.py. [UNIT-alarm_priority@rf71bb757](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676)


<!-- endsection:purpose.UNIT-alarm_priority -->

<!-- section:interfaces.UNIT-alarm_priority -->
### Extracted interfaces

| Signature | 
| --- | 
| def highest(alarms: list[dict]) -> dict \| None | 
| def __init__(self) -> None | 
| def update(self, code: str, priority: int, active: bool) -> None | 
| def select(self) -> dict \| None | 
| def clear_inactive(self) -> None | 
| def snapshot(self) -> list[dict] | 
| def active_count(self) -> int | 


<!-- endsection:interfaces.UNIT-alarm_priority -->

<!-- section:behavior.UNIT-alarm_priority -->
### Behavior and algorithm

<!-- dhf-claim:869bbb860543c3e2 -->
Alarm Manager records events independently of display refresh, orders visible alarms by priority, and keeps an unsafe condition active after acknowledgement. Critical active alarms request inhibited delivery; audio and display present that latch without owning its recovery state. [COMP-04@reec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:91cfb6ea771c3fbd -->
Prioritize critical faults over advisories. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-011@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/32?rev=1)

<!-- dhf-claim:2dcad8a795ad0b95 -->
alarm_priority is implemented in kestrel/alarm_priority.py. [UNIT-alarm_priority@rf71bb757](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676)


<!-- endsection:behavior.UNIT-alarm_priority -->

<!-- section:structures.UNIT-alarm_priority -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| PrioritySelector | — | — | 


<!-- endsection:structures.UNIT-alarm_priority -->

<!-- section:errors.UNIT-alarm_priority -->
### Error handling

<!-- dhf-claim:869bbb860543c3e2 -->
Alarm Manager records events independently of display refresh, orders visible alarms by priority, and keeps an unsafe condition active after acknowledgement. Critical active alarms request inhibited delivery; audio and display present that latch without owning its recovery state. [COMP-04@reec25a71](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:91cfb6ea771c3fbd -->
Prioritize critical faults over advisories. This behavior belongs to COMP-04 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-011@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/32?rev=1)

<!-- dhf-claim:2dcad8a795ad0b95 -->
alarm_priority is implemented in kestrel/alarm_priority.py. [UNIT-alarm_priority@rf71bb757](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GCa2dde2826e3f1fa58388dde08487dbb2c41bb676)


<!-- endsection:errors.UNIT-alarm_priority -->

<!-- section:allocation.UNIT-alarm_priority -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-011](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/32?rev=1) | 1 | [RC-05](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/69?rev=1) | 


<!-- endsection:allocation.UNIT-alarm_priority -->

<!-- section:tests.UNIT-alarm_priority -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-alarm_priority -->

<!-- section:identity.UNIT-comms_frame -->
## UNIT-comms_frame: comms_frame

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-comms_frame@73b95536](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0) | [COMP-06@c50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/comms_frame.py | 


<!-- endsection:identity.UNIT-comms_frame -->

<!-- section:purpose.UNIT-comms_frame -->
### Purpose

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:c0733095824bc0aa -->
Validate incoming message framing. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-026@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/47?rev=1)

<!-- dhf-claim:071e977b33c68cc0 -->
comms_frame is implemented in kestrel/comms_frame.py. [UNIT-comms_frame@r73b95536](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0)


<!-- endsection:purpose.UNIT-comms_frame -->

<!-- section:interfaces.UNIT-comms_frame -->
### Extracted interfaces

| Signature | 
| --- | 
| def valid_frame(payload: bytes) -> bool | 
| def __init__(self, maximum_bytes: int=1024) -> None | 
| def append(self, chunk: bytes) -> list[bytes] | 
| def reset(self) -> None | 


<!-- endsection:interfaces.UNIT-comms_frame -->

<!-- section:behavior.UNIT-comms_frame -->
### Behavior and algorithm

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:c0733095824bc0aa -->
Validate incoming message framing. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-026@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/47?rev=1)

<!-- dhf-claim:071e977b33c68cc0 -->
comms_frame is implemented in kestrel/comms_frame.py. [UNIT-comms_frame@r73b95536](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0)


<!-- endsection:behavior.UNIT-comms_frame -->

<!-- section:structures.UNIT-comms_frame -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| FrameBuffer | — | — | 


<!-- endsection:structures.UNIT-comms_frame -->

<!-- section:errors.UNIT-comms_frame -->
### Error handling

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:c0733095824bc0aa -->
Validate incoming message framing. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-026@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/47?rev=1)

<!-- dhf-claim:071e977b33c68cc0 -->
comms_frame is implemented in kestrel/comms_frame.py. [UNIT-comms_frame@r73b95536](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0)


<!-- endsection:errors.UNIT-comms_frame -->

<!-- section:allocation.UNIT-comms_frame -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-026](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/47?rev=1) | 1 | — | 


<!-- endsection:allocation.UNIT-comms_frame -->

<!-- section:tests.UNIT-comms_frame -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-comms_frame -->

<!-- section:identity.UNIT-comms_timeout -->
## UNIT-comms_timeout: comms_timeout

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-comms_timeout@9f794d28](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0) | [COMP-06@c50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/comms_timeout.py | 


<!-- endsection:identity.UNIT-comms_timeout -->

<!-- section:purpose.UNIT-comms_timeout -->
### Purpose

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:7eb92cd2f1516bf2 -->
Signal a timeout when a response is overdue. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-027@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/48?rev=1)

<!-- dhf-claim:a5f2a68740edb76b -->
Stop output when watchdog heartbeat expires. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-029@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/50?rev=1)


<!-- endsection:purpose.UNIT-comms_timeout -->

<!-- section:interfaces.UNIT-comms_timeout -->
### Extracted interfaces

| Signature | 
| --- | 
| def overdue(now: float, last: float, timeout: float) -> bool | 
| def __init__(self, timeout_s: float) -> None | 
| def response(self, now: float) -> None | 
| def poll(self, now: float) -> bool | 
| def snapshot(self) -> dict | 


<!-- endsection:interfaces.UNIT-comms_timeout -->

<!-- section:behavior.UNIT-comms_timeout -->
### Behavior and algorithm

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:7eb92cd2f1516bf2 -->
Signal a timeout when a response is overdue. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-027@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/48?rev=1)

<!-- dhf-claim:a5f2a68740edb76b -->
Stop output when watchdog heartbeat expires. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-029@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/50?rev=1)


<!-- endsection:behavior.UNIT-comms_timeout -->

<!-- section:structures.UNIT-comms_timeout -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| Heartbeat | — | — | 


<!-- endsection:structures.UNIT-comms_timeout -->

<!-- section:errors.UNIT-comms_timeout -->
### Error handling

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:7eb92cd2f1516bf2 -->
Signal a timeout when a response is overdue. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-027@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/48?rev=1)

<!-- dhf-claim:a5f2a68740edb76b -->
Stop output when watchdog heartbeat expires. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-029@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/50?rev=1)


<!-- endsection:errors.UNIT-comms_timeout -->

<!-- section:allocation.UNIT-comms_timeout -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-027](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/48?rev=1) | 1 | — | 
| [SRS-029](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/50?rev=1) | 1 | [RC-08](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/72?rev=1) | 


<!-- endsection:allocation.UNIT-comms_timeout -->

<!-- section:tests.UNIT-comms_timeout -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-comms_timeout -->

<!-- section:identity.UNIT-diagnostics_trace -->
## UNIT-diagnostics_trace: diagnostics_trace

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-diagnostics_trace@0e543199](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GC5a164f4aad86960f67905d3e6bdebbe615244931) | [COMP-06@c50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/diagnostics_trace.py | 


<!-- endsection:identity.UNIT-diagnostics_trace -->

<!-- section:purpose.UNIT-diagnostics_trace -->
### Purpose

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:234039978e0e8c13 -->
diagnostics_trace is implemented in kestrel/diagnostics_trace.py. [UNIT-diagnostics_trace@r0e543199](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GC5a164f4aad86960f67905d3e6bdebbe615244931)


<!-- endsection:purpose.UNIT-diagnostics_trace -->

<!-- section:interfaces.UNIT-diagnostics_trace -->
### Extracted interfaces

| Signature | 
| --- | 
| def diagnostic_summary(values: list[float]) -> dict | 


<!-- endsection:interfaces.UNIT-diagnostics_trace -->

<!-- section:behavior.UNIT-diagnostics_trace -->
### Behavior and algorithm

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:234039978e0e8c13 -->
diagnostics_trace is implemented in kestrel/diagnostics_trace.py. [UNIT-diagnostics_trace@r0e543199](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GC5a164f4aad86960f67905d3e6bdebbe615244931)


<!-- endsection:behavior.UNIT-diagnostics_trace -->

<!-- section:structures.UNIT-diagnostics_trace -->
### Extracted data structures


<!-- endsection:structures.UNIT-diagnostics_trace -->

<!-- section:errors.UNIT-diagnostics_trace -->
### Error handling

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:234039978e0e8c13 -->
diagnostics_trace is implemented in kestrel/diagnostics_trace.py. [UNIT-diagnostics_trace@r0e543199](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GC5a164f4aad86960f67905d3e6bdebbe615244931)


<!-- endsection:errors.UNIT-diagnostics_trace -->

<!-- section:allocation.UNIT-diagnostics_trace -->
### Allocated requirements and risk controls


<!-- endsection:allocation.UNIT-diagnostics_trace -->

<!-- section:tests.UNIT-diagnostics_trace -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-diagnostics_trace -->

<!-- section:identity.UNIT-drug_limits -->
## UNIT-drug_limits: drug_limits

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-drug_limits@e7d7f0a4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GCc032720ec90c44ee6a301edc34e4433eda0523b8) | [COMP-05@17b6bad7](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/drug_limits.py | 


<!-- endsection:identity.UNIT-drug_limits -->

<!-- section:purpose.UNIT-drug_limits -->
### Purpose

<!-- dhf-claim:ed9196ec5c14072a -->
Drug Library resolves stable record keys and validates dose/rate against configured bounds before activation. Invalid values and missing records prevent configuration acceptance. Its validated limits support Infusion Control and are presented through operator configuration. [COMP-05@r17b6bad7](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:02b2ffcdea9f3b71 -->
Calculate dose from concentration and volume. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-007@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/28?rev=1)

<!-- dhf-claim:96b6f43682076fd7 -->
Reject doses outside library limits. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-018@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/39?rev=1)


<!-- endsection:purpose.UNIT-drug_limits -->

<!-- section:interfaces.UNIT-drug_limits -->
### Extracted interfaces

| Signature | 
| --- | 
| def valid_dose(dose: float, minimum: float, maximum: float) -> bool | 
| def validate(self) -> None | 
| def __init__(self, limits: DrugLimits) | 
| def volume_for(self, dose: float) -> float | 
| def check_proposal(self, proposal: dict) -> dict | 


<!-- endsection:interfaces.UNIT-drug_limits -->

<!-- section:behavior.UNIT-drug_limits -->
### Behavior and algorithm

<!-- dhf-claim:ed9196ec5c14072a -->
Drug Library resolves stable record keys and validates dose/rate against configured bounds before activation. Invalid values and missing records prevent configuration acceptance. Its validated limits support Infusion Control and are presented through operator configuration. [COMP-05@r17b6bad7](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:02b2ffcdea9f3b71 -->
Calculate dose from concentration and volume. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-007@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/28?rev=1)

<!-- dhf-claim:96b6f43682076fd7 -->
Reject doses outside library limits. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-018@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/39?rev=1)


<!-- endsection:behavior.UNIT-drug_limits -->

<!-- section:structures.UNIT-drug_limits -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| DrugLimits | — | key: str<br>minimum_dose: float<br>maximum_dose: float<br>concentration: float | 
| DoseValidator | — | — | 


<!-- endsection:structures.UNIT-drug_limits -->

<!-- section:errors.UNIT-drug_limits -->
### Error handling

<!-- dhf-claim:ed9196ec5c14072a -->
Drug Library resolves stable record keys and validates dose/rate against configured bounds before activation. Invalid values and missing records prevent configuration acceptance. Its validated limits support Infusion Control and are presented through operator configuration. [COMP-05@r17b6bad7](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:02b2ffcdea9f3b71 -->
Calculate dose from concentration and volume. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-007@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/28?rev=1)

<!-- dhf-claim:96b6f43682076fd7 -->
Reject doses outside library limits. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-018@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/39?rev=1)


<!-- endsection:errors.UNIT-drug_limits -->

<!-- section:allocation.UNIT-drug_limits -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-007](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/28?rev=1) | 1 | — | 
| [SRS-018](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/39?rev=1) | 1 | [RC-06](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/70?rev=1) | 


<!-- endsection:allocation.UNIT-drug_limits -->

<!-- section:tests.UNIT-drug_limits -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-drug_limits -->

<!-- section:identity.UNIT-drug_lookup -->
## UNIT-drug_lookup: drug_lookup

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-drug_lookup@9b215c47](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GCc032720ec90c44ee6a301edc34e4433eda0523b8) | [COMP-05@17b6bad7](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/drug_lookup.py | 


<!-- endsection:identity.UNIT-drug_lookup -->

<!-- section:purpose.UNIT-drug_lookup -->
### Purpose

<!-- dhf-claim:ed9196ec5c14072a -->
Drug Library resolves stable record keys and validates dose/rate against configured bounds before activation. Invalid values and missing records prevent configuration acceptance. Its validated limits support Infusion Control and are presented through operator configuration. [COMP-05@r17b6bad7](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:db1ffb6fc33b2a94 -->
Find configured drug records by stable key. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-019@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/40?rev=1)

<!-- dhf-claim:fde79aeaee61b37a -->
Reject a library with invalid checksum. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-020@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/41?rev=1)


<!-- endsection:purpose.UNIT-drug_lookup -->

<!-- section:interfaces.UNIT-drug_lookup -->
### Extracted interfaces

| Signature | 
| --- | 
| def lookup(library: dict, key: str) -> dict | 
| def __init__(self, records: dict) -> None | 
| def get(self, key: str) -> dict | 
| def keys(self) -> list[str] | 
| def select(self, key: str, dose: float) -> dict | 


<!-- endsection:interfaces.UNIT-drug_lookup -->

<!-- section:behavior.UNIT-drug_lookup -->
### Behavior and algorithm

<!-- dhf-claim:ed9196ec5c14072a -->
Drug Library resolves stable record keys and validates dose/rate against configured bounds before activation. Invalid values and missing records prevent configuration acceptance. Its validated limits support Infusion Control and are presented through operator configuration. [COMP-05@r17b6bad7](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:db1ffb6fc33b2a94 -->
Find configured drug records by stable key. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-019@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/40?rev=1)

<!-- dhf-claim:fde79aeaee61b37a -->
Reject a library with invalid checksum. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-020@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/41?rev=1)


<!-- endsection:behavior.UNIT-drug_lookup -->

<!-- section:structures.UNIT-drug_lookup -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| DrugLibrary | — | — | 


<!-- endsection:structures.UNIT-drug_lookup -->

<!-- section:errors.UNIT-drug_lookup -->
### Error handling

<!-- dhf-claim:ed9196ec5c14072a -->
Drug Library resolves stable record keys and validates dose/rate against configured bounds before activation. Invalid values and missing records prevent configuration acceptance. Its validated limits support Infusion Control and are presented through operator configuration. [COMP-05@r17b6bad7](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:db1ffb6fc33b2a94 -->
Find configured drug records by stable key. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-019@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/40?rev=1)

<!-- dhf-claim:fde79aeaee61b37a -->
Reject a library with invalid checksum. This behavior belongs to COMP-05 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-020@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/41?rev=1)


<!-- endsection:errors.UNIT-drug_lookup -->

<!-- section:allocation.UNIT-drug_lookup -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-019](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/40?rev=1) | 1 | [RC-06](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/70?rev=1) | 
| [SRS-020](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/41?rev=1) | 1 | [RC-06](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/70?rev=1) | 


<!-- endsection:allocation.UNIT-drug_lookup -->

<!-- section:tests.UNIT-drug_lookup -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-drug_lookup -->

<!-- section:identity.UNIT-infusion_bounds -->
## UNIT-infusion_bounds: infusion_bounds

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCfdf6de366e5cbe8be52996ded854b8a1ba25befc) | [COMP-02@d5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/infusion_bounds.py | 


<!-- endsection:identity.UNIT-infusion_bounds -->

<!-- section:purpose.UNIT-infusion_bounds -->
### Purpose

<!-- dhf-claim:1bcb3095f54fd5dc -->
Infusion Control validates DeliveryConfiguration atomically before start, rejects configuration edits while running, and clamps each delivered increment to remaining target volume. Sensor Monitoring supplies safe/fault decisions; Alarm Manager supplies active critical latches. Faults inhibit delivery and restart requires a valid configuration. [COMP-02@rd5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:4ac0537e3a78215e -->
Reject flow outside configured bounds. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-001@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/22?rev=1)

<!-- dhf-claim:f8e42015849e8c05 -->
Reject start when configuration is invalid. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-003@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/24?rev=1)


<!-- endsection:purpose.UNIT-infusion_bounds -->

<!-- section:interfaces.UNIT-infusion_bounds -->
### Extracted interfaces

| Signature | 
| --- | 
| def within_bounds(rate: float, minimum: float, maximum: float) -> bool | 
| def validate(self) -> None | 
| def __init__(self) -> None | 
| def configure(self, proposed: DeliveryConfiguration) -> None | 
| def start(self, sensor_safe: bool, alarm_active: bool) -> None | 
| def tick(self, elapsed_s: float, sensor_safe: bool) -> float | 
| def pause(self) -> None | 
| def stop(self) -> None | 


<!-- endsection:interfaces.UNIT-infusion_bounds -->

<!-- section:behavior.UNIT-infusion_bounds -->
### Behavior and algorithm

<!-- dhf-claim:1bcb3095f54fd5dc -->
Infusion Control validates DeliveryConfiguration atomically before start, rejects configuration edits while running, and clamps each delivered increment to remaining target volume. Sensor Monitoring supplies safe/fault decisions; Alarm Manager supplies active critical latches. Faults inhibit delivery and restart requires a valid configuration. [COMP-02@rd5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:4ac0537e3a78215e -->
Reject flow outside configured bounds. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-001@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/22?rev=1)

<!-- dhf-claim:f8e42015849e8c05 -->
Reject start when configuration is invalid. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-003@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/24?rev=1)


<!-- endsection:behavior.UNIT-infusion_bounds -->

<!-- section:structures.UNIT-infusion_bounds -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| DeliveryMode | StrEnum | STOPPED = 'stopped'<br>RUNNING = 'running'<br>PAUSED = 'paused'<br>FAULT = 'fault' | 
| DeliveryConfiguration | — | rate_ml_h: float<br>target_ml: float<br>maximum_rate_ml_h: float | 
| DeliveryController | — | — | 


<!-- endsection:structures.UNIT-infusion_bounds -->

<!-- section:errors.UNIT-infusion_bounds -->
### Error handling

<!-- dhf-claim:1bcb3095f54fd5dc -->
Infusion Control validates DeliveryConfiguration atomically before start, rejects configuration edits while running, and clamps each delivered increment to remaining target volume. Sensor Monitoring supplies safe/fault decisions; Alarm Manager supplies active critical latches. Faults inhibit delivery and restart requires a valid configuration. [COMP-02@rd5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:4ac0537e3a78215e -->
Reject flow outside configured bounds. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-001@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/22?rev=1)

<!-- dhf-claim:f8e42015849e8c05 -->
Reject start when configuration is invalid. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-003@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/24?rev=1)


<!-- endsection:errors.UNIT-infusion_bounds -->

<!-- section:allocation.UNIT-infusion_bounds -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-001](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/22?rev=1) | 1 | [RC-01](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/65?rev=1) | 
| [SRS-003](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/24?rev=1) | 1 | [RC-11](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/75?rev=1) | 
| [SRS-004](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/25?rev=1) | 1 | — | 
| [SRS-005](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/26?rev=1) | 1 | — | 
| [SRS-030](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/51?rev=2) | 2 | [RC-08](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/72?rev=1) | 


<!-- endsection:allocation.UNIT-infusion_bounds -->

<!-- section:tests.UNIT-infusion_bounds -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-infusion_bounds -->

<!-- section:identity.UNIT-infusion_motor -->
## UNIT-infusion_motor: infusion_motor

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-infusion_motor@eb1bd363](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCfdf6de366e5cbe8be52996ded854b8a1ba25befc) | [COMP-02@d5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/infusion_motor.py | 


<!-- endsection:identity.UNIT-infusion_motor -->

<!-- section:purpose.UNIT-infusion_motor -->
### Purpose

<!-- dhf-claim:1bcb3095f54fd5dc -->
Infusion Control validates DeliveryConfiguration atomically before start, rejects configuration edits while running, and clamps each delivered increment to remaining target volume. Sensor Monitoring supplies safe/fault decisions; Alarm Manager supplies active critical latches. Faults inhibit delivery and restart requires a valid configuration. [COMP-02@rd5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:d8f4e9646774f359 -->
Convert flow into motor pulse intervals. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-006@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/27?rev=1)

<!-- dhf-claim:a8132dff3e4466f7 -->
infusion_motor is implemented in kestrel/infusion_motor.py. [UNIT-infusion_motor@reb1bd363](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCfdf6de366e5cbe8be52996ded854b8a1ba25befc)


<!-- endsection:purpose.UNIT-infusion_motor -->

<!-- section:interfaces.UNIT-infusion_motor -->
### Extracted interfaces

| Signature | 
| --- | 
| def pulse_interval(rate: float, pulses_per_ml: int) -> float | 
| def __init__(self, pulses_per_ml: int) -> None | 
| def configure(self, rate: float) -> None | 
| def pulses(self, elapsed_s: float, enabled: bool) -> int | 


<!-- endsection:interfaces.UNIT-infusion_motor -->

<!-- section:behavior.UNIT-infusion_motor -->
### Behavior and algorithm

<!-- dhf-claim:1bcb3095f54fd5dc -->
Infusion Control validates DeliveryConfiguration atomically before start, rejects configuration edits while running, and clamps each delivered increment to remaining target volume. Sensor Monitoring supplies safe/fault decisions; Alarm Manager supplies active critical latches. Faults inhibit delivery and restart requires a valid configuration. [COMP-02@rd5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:d8f4e9646774f359 -->
Convert flow into motor pulse intervals. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-006@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/27?rev=1)

<!-- dhf-claim:a8132dff3e4466f7 -->
infusion_motor is implemented in kestrel/infusion_motor.py. [UNIT-infusion_motor@reb1bd363](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCfdf6de366e5cbe8be52996ded854b8a1ba25befc)


<!-- endsection:behavior.UNIT-infusion_motor -->

<!-- section:structures.UNIT-infusion_motor -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| MotorSchedule | — | — | 


<!-- endsection:structures.UNIT-infusion_motor -->

<!-- section:errors.UNIT-infusion_motor -->
### Error handling

<!-- dhf-claim:1bcb3095f54fd5dc -->
Infusion Control validates DeliveryConfiguration atomically before start, rejects configuration edits while running, and clamps each delivered increment to remaining target volume. Sensor Monitoring supplies safe/fault decisions; Alarm Manager supplies active critical latches. Faults inhibit delivery and restart requires a valid configuration. [COMP-02@rd5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:d8f4e9646774f359 -->
Convert flow into motor pulse intervals. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-006@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/27?rev=1)

<!-- dhf-claim:a8132dff3e4466f7 -->
infusion_motor is implemented in kestrel/infusion_motor.py. [UNIT-infusion_motor@reb1bd363](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCfdf6de366e5cbe8be52996ded854b8a1ba25befc)


<!-- endsection:errors.UNIT-infusion_motor -->

<!-- section:allocation.UNIT-infusion_motor -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-006](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/27?rev=1) | 1 | [RC-02](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/66?rev=1) | 


<!-- endsection:allocation.UNIT-infusion_motor -->

<!-- section:tests.UNIT-infusion_motor -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-infusion_motor -->

<!-- section:identity.UNIT-infusion_volume -->
## UNIT-infusion_volume: infusion_volume

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-infusion_volume@0b716c6e](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCfdf6de366e5cbe8be52996ded854b8a1ba25befc) | [COMP-02@d5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/infusion_volume.py | 


<!-- endsection:identity.UNIT-infusion_volume -->

<!-- section:purpose.UNIT-infusion_volume -->
### Purpose

<!-- dhf-claim:1bcb3095f54fd5dc -->
Infusion Control validates DeliveryConfiguration atomically before start, rejects configuration edits while running, and clamps each delivered increment to remaining target volume. Sensor Monitoring supplies safe/fault decisions; Alarm Manager supplies active critical latches. Faults inhibit delivery and restart requires a valid configuration. [COMP-02@rd5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:9f3e7875264a2c0c -->
Stop when delivered volume reaches configured target. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-002@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/23?rev=1)

<!-- dhf-claim:0b8ef7c1576d514e -->
Integrate commanded flow over elapsed time. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-028@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/49?rev=1)


<!-- endsection:purpose.UNIT-infusion_volume -->

<!-- section:interfaces.UNIT-infusion_volume -->
### Extracted interfaces

| Signature | 
| --- | 
| def target_reached(delivered: float, target: float) -> bool | 
| def __init__(self, target: float) -> None | 
| def add(self, requested: float) -> float | 
| def stop(self) -> None | 
| def snapshot(self) -> dict | 


<!-- endsection:interfaces.UNIT-infusion_volume -->

<!-- section:behavior.UNIT-infusion_volume -->
### Behavior and algorithm

<!-- dhf-claim:1bcb3095f54fd5dc -->
Infusion Control validates DeliveryConfiguration atomically before start, rejects configuration edits while running, and clamps each delivered increment to remaining target volume. Sensor Monitoring supplies safe/fault decisions; Alarm Manager supplies active critical latches. Faults inhibit delivery and restart requires a valid configuration. [COMP-02@rd5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:9f3e7875264a2c0c -->
Stop when delivered volume reaches configured target. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-002@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/23?rev=1)

<!-- dhf-claim:0b8ef7c1576d514e -->
Integrate commanded flow over elapsed time. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-028@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/49?rev=1)


<!-- endsection:behavior.UNIT-infusion_volume -->

<!-- section:structures.UNIT-infusion_volume -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| VolumeAccumulator | — | — | 


<!-- endsection:structures.UNIT-infusion_volume -->

<!-- section:errors.UNIT-infusion_volume -->
### Error handling

<!-- dhf-claim:1bcb3095f54fd5dc -->
Infusion Control validates DeliveryConfiguration atomically before start, rejects configuration edits while running, and clamps each delivered increment to remaining target volume. Sensor Monitoring supplies safe/fault decisions; Alarm Manager supplies active critical latches. Faults inhibit delivery and restart requires a valid configuration. [COMP-02@rd5c8005b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:9f3e7875264a2c0c -->
Stop when delivered volume reaches configured target. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-002@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/23?rev=1)

<!-- dhf-claim:0b8ef7c1576d514e -->
Integrate commanded flow over elapsed time. This behavior belongs to COMP-02 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-028@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/49?rev=1)


<!-- endsection:errors.UNIT-infusion_volume -->

<!-- section:allocation.UNIT-infusion_volume -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-002](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/23?rev=1) | 1 | [RC-01](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/65?rev=1) | 
| [SRS-028](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/49?rev=1) | 1 | [RC-01](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/65?rev=1) | 


<!-- endsection:allocation.UNIT-infusion_volume -->

<!-- section:tests.UNIT-infusion_volume -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-infusion_volume -->

<!-- section:identity.UNIT-log_digest -->
## UNIT-log_digest: log_digest

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-log_digest@ab99e552](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0) | [COMP-06@c50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/log_digest.py | 


<!-- endsection:identity.UNIT-log_digest -->

<!-- section:purpose.UNIT-log_digest -->
### Purpose

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:2809ba4306e015fb -->
Detect modified log records using content digests. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-025@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/46?rev=1)

<!-- dhf-claim:0e147d3f5307cdcd -->
log_digest is implemented in kestrel/log_digest.py. [UNIT-log_digest@rab99e552](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0)


<!-- endsection:purpose.UNIT-log_digest -->

<!-- section:interfaces.UNIT-log_digest -->
### Extracted interfaces

| Signature | 
| --- | 
| def digest(payload: bytes) -> str | 
| def __init__(self, payload: bytes) -> None | 
| def verify(self, candidate: bytes) -> bool | 
| def describe(self) -> dict | 
| def require_valid(self, candidate: bytes) -> None | 


<!-- endsection:interfaces.UNIT-log_digest -->

<!-- section:behavior.UNIT-log_digest -->
### Behavior and algorithm

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:2809ba4306e015fb -->
Detect modified log records using content digests. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-025@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/46?rev=1)

<!-- dhf-claim:0e147d3f5307cdcd -->
log_digest is implemented in kestrel/log_digest.py. [UNIT-log_digest@rab99e552](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0)


<!-- endsection:behavior.UNIT-log_digest -->

<!-- section:structures.UNIT-log_digest -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| IntegrityRecord | — | — | 


<!-- endsection:structures.UNIT-log_digest -->

<!-- section:errors.UNIT-log_digest -->
### Error handling

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:2809ba4306e015fb -->
Detect modified log records using content digests. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-025@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/46?rev=1)

<!-- dhf-claim:0e147d3f5307cdcd -->
log_digest is implemented in kestrel/log_digest.py. [UNIT-log_digest@rab99e552](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0)


<!-- endsection:errors.UNIT-log_digest -->

<!-- section:allocation.UNIT-log_digest -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-025](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/46?rev=1) | 1 | [RC-07](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/71?rev=1) | 


<!-- endsection:allocation.UNIT-log_digest -->

<!-- section:tests.UNIT-log_digest -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-log_digest -->

<!-- section:identity.UNIT-log_events -->
## UNIT-log_events: log_events

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-log_events@92fbf9b0](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GC07c16734734292d7e99c3e57c9bf9f81c4e5f6c0) | [COMP-06@c50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/log_events.py | 


<!-- endsection:identity.UNIT-log_events -->

<!-- section:purpose.UNIT-log_events -->
### Purpose

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ffb4761194aab33b -->
Append ordered events to the audit log. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-024@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/45?rev=1)

<!-- dhf-claim:ef54821870fd133e -->
Reject decreasing event timestamps. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-031@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/52?rev=1)


<!-- endsection:purpose.UNIT-log_events -->

<!-- section:interfaces.UNIT-log_events -->
### Extracted interfaces

| Signature | 
| --- | 
| def append_event(events: list[dict], event: dict) -> list[dict] | 
| def __init__(self) -> None | 
| def record(self, event: AuditEvent) -> None | 
| def export(self) -> list[dict] | 
| def content_digest(self) -> str | 


<!-- endsection:interfaces.UNIT-log_events -->

<!-- section:behavior.UNIT-log_events -->
### Behavior and algorithm

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ffb4761194aab33b -->
Append ordered events to the audit log. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-024@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/45?rev=1)

<!-- dhf-claim:ef54821870fd133e -->
Reject decreasing event timestamps. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-031@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/52?rev=1)


<!-- endsection:behavior.UNIT-log_events -->

<!-- section:structures.UNIT-log_events -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| AuditEvent | — | time: float<br>code: str<br>details: dict | 
| EventRecorder | — | — | 


<!-- endsection:structures.UNIT-log_events -->

<!-- section:errors.UNIT-log_events -->
### Error handling

<!-- dhf-claim:1a9b1d2eb0e075dc -->
Comms & Logging retains ordered timestamped events, hashes records for integrity checks, validates framed messages and detects communication timeout. Diagnostics captures trace summaries. These services report faults; they do not own the delivery stop path. [COMP-06@rc50ffebb](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ffb4761194aab33b -->
Append ordered events to the audit log. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-024@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/45?rev=1)

<!-- dhf-claim:ef54821870fd133e -->
Reject decreasing event timestamps. This behavior belongs to COMP-06 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-031@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/52?rev=1)


<!-- endsection:errors.UNIT-log_events -->

<!-- section:allocation.UNIT-log_events -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-024](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/45?rev=1) | 1 | [RC-07](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/71?rev=1) | 
| [SRS-031](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/52?rev=1) | 1 | — | 
| [SRS-033](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/54?rev=1) | 1 | [RC-07](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/71?rev=1) | 


<!-- endsection:allocation.UNIT-log_events -->

<!-- section:tests.UNIT-log_events -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-log_events -->

<!-- section:identity.UNIT-sensor_air -->
## UNIT-sensor_air: sensor_air

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-sensor_air@f8cd0f72](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0) | [COMP-03@9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/sensor_air.py | 


<!-- endsection:identity.UNIT-sensor_air -->

<!-- section:purpose.UNIT-sensor_air -->
### Purpose

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:bf612b4e26a816b7 -->
Stop infusion when air sensor exceeds the configured limit. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-008@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/29?rev=1)

<!-- dhf-claim:bcf602497d412158 -->
Latch a fault when the sensor disconnects. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-010@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/31?rev=1)


<!-- endsection:purpose.UNIT-sensor_air -->

<!-- section:interfaces.UNIT-sensor_air -->
### Extracted interfaces

| Signature | 
| --- | 
| def air_detected(reading: float, limit: float) -> bool | 
| def __init__(self, limit: float) | 
| def evaluate(self, reading: float \| None, connected: bool=True) -> AirDecision | 
| def acknowledge(self, reading: float, connected: bool=True) -> bool | 


<!-- endsection:interfaces.UNIT-sensor_air -->

<!-- section:behavior.UNIT-sensor_air -->
### Behavior and algorithm

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:bf612b4e26a816b7 -->
Stop infusion when air sensor exceeds the configured limit. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-008@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/29?rev=1)

<!-- dhf-claim:bcf602497d412158 -->
Latch a fault when the sensor disconnects. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-010@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/31?rev=1)


<!-- endsection:behavior.UNIT-sensor_air -->

<!-- section:structures.UNIT-sensor_air -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| AirDecision | — | stop_output: bool<br>alarm_required: bool<br>reason: str | 
| AirMonitor | — | — | 


<!-- endsection:structures.UNIT-sensor_air -->

<!-- section:errors.UNIT-sensor_air -->
### Error handling

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:bf612b4e26a816b7 -->
Stop infusion when air sensor exceeds the configured limit. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-008@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/29?rev=1)

<!-- dhf-claim:bcf602497d412158 -->
Latch a fault when the sensor disconnects. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-010@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/31?rev=1)


<!-- endsection:errors.UNIT-sensor_air -->

<!-- section:allocation.UNIT-sensor_air -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-008](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/29?rev=1) | 1 | [RC-02](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/66?rev=1)<br>[RC-03](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/67?rev=1) | 
| [SRS-010](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/31?rev=1) | 1 | [RC-10](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/74?rev=1) | 


<!-- endsection:allocation.UNIT-sensor_air -->

<!-- section:tests.UNIT-sensor_air -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-sensor_air -->

<!-- section:identity.UNIT-sensor_calibration -->
## UNIT-sensor_calibration: sensor_calibration

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-sensor_calibration@605da84b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0) | [COMP-03@9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/sensor_calibration.py | 


<!-- endsection:identity.UNIT-sensor_calibration -->

<!-- section:purpose.UNIT-sensor_calibration -->
### Purpose

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:cd6c104dbde73c6f -->
Apply calibration offset to valid readings. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-023@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/44?rev=1)

<!-- dhf-claim:efc790ce56a7a4e1 -->
sensor_calibration is implemented in kestrel/sensor_calibration.py. [UNIT-sensor_calibration@r605da84b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0)


<!-- endsection:purpose.UNIT-sensor_calibration -->

<!-- section:interfaces.UNIT-sensor_calibration -->
### Extracted interfaces

| Signature | 
| --- | 
| def calibrated(reading: float, offset: float) -> float | 
| def __init__(self, gain: float=1.0, offset: float=0.0) -> None | 
| def apply(self, reading: float) -> float | 
| def update(self, gain: float, offset: float, authorized: bool) -> None | 
| def snapshot(self) -> dict | 


<!-- endsection:interfaces.UNIT-sensor_calibration -->

<!-- section:behavior.UNIT-sensor_calibration -->
### Behavior and algorithm

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:cd6c104dbde73c6f -->
Apply calibration offset to valid readings. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-023@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/44?rev=1)

<!-- dhf-claim:efc790ce56a7a4e1 -->
sensor_calibration is implemented in kestrel/sensor_calibration.py. [UNIT-sensor_calibration@r605da84b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0)


<!-- endsection:behavior.UNIT-sensor_calibration -->

<!-- section:structures.UNIT-sensor_calibration -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| Calibration | — | — | 


<!-- endsection:structures.UNIT-sensor_calibration -->

<!-- section:errors.UNIT-sensor_calibration -->
### Error handling

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:cd6c104dbde73c6f -->
Apply calibration offset to valid readings. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-023@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/44?rev=1)

<!-- dhf-claim:efc790ce56a7a4e1 -->
sensor_calibration is implemented in kestrel/sensor_calibration.py. [UNIT-sensor_calibration@r605da84b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0)


<!-- endsection:errors.UNIT-sensor_calibration -->

<!-- section:allocation.UNIT-sensor_calibration -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-023](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | 1 | [RC-09](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/73?rev=1) | 


<!-- endsection:allocation.UNIT-sensor_calibration -->

<!-- section:tests.UNIT-sensor_calibration -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-sensor_calibration -->

<!-- section:identity.UNIT-sensor_filter -->
## UNIT-sensor_filter: sensor_filter

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-sensor_filter@8b9b8bc9](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0) | [COMP-03@9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/sensor_filter.py | 


<!-- endsection:identity.UNIT-sensor_filter -->

<!-- section:purpose.UNIT-sensor_filter -->
### Purpose

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:00dd89f57c5b72ed -->
Filter pressure samples over the configured window. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-022@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/43?rev=1)

<!-- dhf-claim:09011b9d0796f7d6 -->
sensor_filter is implemented in kestrel/sensor_filter.py. [UNIT-sensor_filter@r8b9b8bc9](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0)


<!-- endsection:purpose.UNIT-sensor_filter -->

<!-- section:interfaces.UNIT-sensor_filter -->
### Extracted interfaces

| Signature | 
| --- | 
| def average(samples: list[float]) -> float | 
| def __init__(self, size: int) | 
| def append(self, value: float) -> float | 
| def reset(self) -> None | 
| def snapshot(self) -> dict | 


<!-- endsection:interfaces.UNIT-sensor_filter -->

<!-- section:behavior.UNIT-sensor_filter -->
### Behavior and algorithm

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:00dd89f57c5b72ed -->
Filter pressure samples over the configured window. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-022@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/43?rev=1)

<!-- dhf-claim:09011b9d0796f7d6 -->
sensor_filter is implemented in kestrel/sensor_filter.py. [UNIT-sensor_filter@r8b9b8bc9](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0)


<!-- endsection:behavior.UNIT-sensor_filter -->

<!-- section:structures.UNIT-sensor_filter -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| PressureWindow | — | — | 


<!-- endsection:structures.UNIT-sensor_filter -->

<!-- section:errors.UNIT-sensor_filter -->
### Error handling

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:00dd89f57c5b72ed -->
Filter pressure samples over the configured window. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-022@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/43?rev=1)

<!-- dhf-claim:09011b9d0796f7d6 -->
sensor_filter is implemented in kestrel/sensor_filter.py. [UNIT-sensor_filter@r8b9b8bc9](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC2b18f63b3bb888481ef0b28f9915d945255172e0)


<!-- endsection:errors.UNIT-sensor_filter -->

<!-- section:allocation.UNIT-sensor_filter -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-022](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/43?rev=1) | 1 | [RC-04](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/68?rev=1) | 


<!-- endsection:allocation.UNIT-sensor_filter -->

<!-- section:tests.UNIT-sensor_filter -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-sensor_filter -->

<!-- section:identity.UNIT-sensor_pressure -->
## UNIT-sensor_pressure: sensor_pressure

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-sensor_pressure@a1d3651b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC482be50e10c98d350b31ed735bc32d68e284de91) | [COMP-03@9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/sensor_pressure.py | 


<!-- endsection:identity.UNIT-sensor_pressure -->

<!-- section:purpose.UNIT-sensor_pressure -->
### Purpose

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:3090667d4f3cc2bb -->
Validate pressure readings before use. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-009@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/30?rev=1)

<!-- dhf-claim:fa766f927b0131af -->
The Sensor Monitoring component shall detect downstream occlusion when pressure remains above 75 kPa, stop output and request a latched critical alarm. A bounded dwell filters transient spikes without hiding sustained occlusion. [SRS-021@r2](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/42?rev=2)


<!-- endsection:purpose.UNIT-sensor_pressure -->

<!-- section:interfaces.UNIT-sensor_pressure -->
### Extracted interfaces

| Signature | 
| --- | 
| def occluded(pressure: float, threshold: float=75.0) -> bool | 
| def pressure_alarm(decision: PressureDecision, active: bool, acknowledged: bool) -> bool | 
| def __init__(self, threshold_kpa: float=75.0, dwell_s: float=3.0) | 
| def evaluate(self, sample: PressureSample \| None) -> PressureDecision | 
| def acknowledge(self, sample: PressureSample) -> bool | 


<!-- endsection:interfaces.UNIT-sensor_pressure -->

<!-- section:behavior.UNIT-sensor_pressure -->
### Behavior and algorithm

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:3090667d4f3cc2bb -->
Validate pressure readings before use. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-009@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/30?rev=1)

<!-- dhf-claim:fa766f927b0131af -->
The Sensor Monitoring component shall detect downstream occlusion when pressure remains above 75 kPa, stop output and request a latched critical alarm. A bounded dwell filters transient spikes without hiding sustained occlusion. [SRS-021@r2](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/42?rev=2)


<!-- endsection:behavior.UNIT-sensor_pressure -->

<!-- section:structures.UNIT-sensor_pressure -->
### Extracted data structures

| Name | Kind / bases | Fields | 
| --- | --- | --- | 
| PressureState | StrEnum | SAFE = 'safe'<br>OCCLUDED = 'occluded'<br>FAULT = 'fault' | 
| PressureSample | — | value_kpa: float<br>timestamp_s: float | 
| PressureDecision | — | state: PressureState<br>stop_output: bool<br>alarm_required: bool<br>reason: str | 
| PressureMonitor | — | — | 


<!-- endsection:structures.UNIT-sensor_pressure -->

<!-- section:errors.UNIT-sensor_pressure -->
### Error handling

<!-- dhf-claim:8cec648f559f47de -->
Sensor Monitoring validates finite ordered pressure samples, applies the configured threshold and dwell interval, and retains an occlusion latch until safe acknowledgement. Air monitoring treats invalid or missing samples as faults. Calibration rejects invalid gain before activation. Pressure decisions request a critical alarm through Alarm Manager. [COMP-03@r9ae26fe4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:3090667d4f3cc2bb -->
Validate pressure readings before use. This behavior belongs to COMP-03 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-009@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/30?rev=1)

<!-- dhf-claim:fa766f927b0131af -->
The Sensor Monitoring component shall detect downstream occlusion when pressure remains above 75 kPa, stop output and request a latched critical alarm. A bounded dwell filters transient spikes without hiding sustained occlusion. [SRS-021@r2](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/42?rev=2)


<!-- endsection:errors.UNIT-sensor_pressure -->

<!-- section:allocation.UNIT-sensor_pressure -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-009](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/30?rev=1) | 1 | [RC-09](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/73?rev=1) | 
| [SRS-021](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/42?rev=2) | 2 | [RC-04](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/68?rev=1) | 


<!-- endsection:allocation.UNIT-sensor_pressure -->

<!-- section:tests.UNIT-sensor_pressure -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-sensor_pressure -->

<!-- section:identity.UNIT-ui_confirm -->
## UNIT-ui_confirm: ui_confirm

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-ui_confirm@4a6745ab](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_confirm.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13) | [COMP-01@b128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/ui_confirm.py | 


<!-- endsection:identity.UNIT-ui_confirm -->

<!-- section:purpose.UNIT-ui_confirm -->
### Purpose

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:01f133059ad0caa8 -->
Require confirmation before applying a new configuration. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-017@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/38?rev=1)

<!-- dhf-claim:73109cb1020feec3 -->
ui_confirm is implemented in kestrel/ui_confirm.py. [UNIT-ui_confirm@r4a6745ab](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_confirm.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13)


<!-- endsection:purpose.UNIT-ui_confirm -->

<!-- section:interfaces.UNIT-ui_confirm -->
### Extracted interfaces

| Signature | 
| --- | 
| def confirm(current: dict, proposed: dict, accepted: bool) -> dict | 


<!-- endsection:interfaces.UNIT-ui_confirm -->

<!-- section:behavior.UNIT-ui_confirm -->
### Behavior and algorithm

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:01f133059ad0caa8 -->
Require confirmation before applying a new configuration. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-017@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/38?rev=1)

<!-- dhf-claim:73109cb1020feec3 -->
ui_confirm is implemented in kestrel/ui_confirm.py. [UNIT-ui_confirm@r4a6745ab](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_confirm.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13)


<!-- endsection:behavior.UNIT-ui_confirm -->

<!-- section:structures.UNIT-ui_confirm -->
### Extracted data structures


<!-- endsection:structures.UNIT-ui_confirm -->

<!-- section:errors.UNIT-ui_confirm -->
### Error handling

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:01f133059ad0caa8 -->
Require confirmation before applying a new configuration. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-017@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/38?rev=1)

<!-- dhf-claim:73109cb1020feec3 -->
ui_confirm is implemented in kestrel/ui_confirm.py. [UNIT-ui_confirm@r4a6745ab](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_confirm.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13)


<!-- endsection:errors.UNIT-ui_confirm -->

<!-- section:allocation.UNIT-ui_confirm -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-017](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/38?rev=1) | 1 | [RC-11](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/75?rev=1) | 


<!-- endsection:allocation.UNIT-ui_confirm -->

<!-- section:tests.UNIT-ui_confirm -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-ui_confirm -->

<!-- section:identity.UNIT-ui_input -->
## UNIT-ui_input: ui_input

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-ui_input@2e563f7b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_input.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13) | [COMP-01@b128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/ui_input.py | 


<!-- endsection:identity.UNIT-ui_input -->

<!-- section:purpose.UNIT-ui_input -->
### Purpose

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:4e899ade35e584d6 -->
Reject malformed operator entries. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-016@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/37?rev=1)

<!-- dhf-claim:4e5160e01de2280a -->
ui_input is implemented in kestrel/ui_input.py. [UNIT-ui_input@r2e563f7b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_input.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13)


<!-- endsection:purpose.UNIT-ui_input -->

<!-- section:interfaces.UNIT-ui_input -->
### Extracted interfaces

| Signature | 
| --- | 
| def parse_rate(value: str, maximum: float) -> float | 


<!-- endsection:interfaces.UNIT-ui_input -->

<!-- section:behavior.UNIT-ui_input -->
### Behavior and algorithm

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:4e899ade35e584d6 -->
Reject malformed operator entries. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-016@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/37?rev=1)

<!-- dhf-claim:4e5160e01de2280a -->
ui_input is implemented in kestrel/ui_input.py. [UNIT-ui_input@r2e563f7b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_input.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13)


<!-- endsection:behavior.UNIT-ui_input -->

<!-- section:structures.UNIT-ui_input -->
### Extracted data structures


<!-- endsection:structures.UNIT-ui_input -->

<!-- section:errors.UNIT-ui_input -->
### Error handling

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:4e899ade35e584d6 -->
Reject malformed operator entries. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-016@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/37?rev=1)

<!-- dhf-claim:4e5160e01de2280a -->
ui_input is implemented in kestrel/ui_input.py. [UNIT-ui_input@r2e563f7b](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_input.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13)


<!-- endsection:errors.UNIT-ui_input -->

<!-- section:allocation.UNIT-ui_input -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-016](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/37?rev=1) | 1 | — | 


<!-- endsection:allocation.UNIT-ui_input -->

<!-- section:tests.UNIT-ui_input -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-ui_input -->

<!-- section:identity.UNIT-ui_status -->
## UNIT-ui_status: ui_status

### Unit identification

| Unit | Parent component | Source path | 
| --- | --- | --- | 
| [UNIT-ui_status@4d866549](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_status.py&version=GCf156d36d1e3e0a8e7093ce20a65dd1e3b87bcf13) | [COMP-01@b128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | kestrel/ui_status.py | 


<!-- endsection:identity.UNIT-ui_status -->

<!-- section:purpose.UNIT-ui_status -->
### Purpose

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ba979271b2179864 -->
Show operating mode and delivered volume. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-015@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/36?rev=1)

<!-- dhf-claim:b32e460352cb344a -->
Expose known residual anomalies to the operator. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-032@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/53?rev=1)


<!-- endsection:purpose.UNIT-ui_status -->

<!-- section:interfaces.UNIT-ui_status -->
### Extracted interfaces

| Signature | 
| --- | 
| def status(mode: str, volume: float) -> dict | 


<!-- endsection:interfaces.UNIT-ui_status -->

<!-- section:behavior.UNIT-ui_status -->
### Behavior and algorithm

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ba979271b2179864 -->
Show operating mode and delivered volume. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-015@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/36?rev=1)

<!-- dhf-claim:b32e460352cb344a -->
Expose known residual anomalies to the operator. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-032@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/53?rev=1)


<!-- endsection:behavior.UNIT-ui_status -->

<!-- section:structures.UNIT-ui_status -->
### Extracted data structures


<!-- endsection:structures.UNIT-ui_status -->

<!-- section:errors.UNIT-ui_status -->
### Error handling

<!-- dhf-claim:ae695f922a6c5edf -->
Accept proposed rate/volume settings through ui_input; ui_confirm retains the previous configuration when the operator cancels. ui_status displays mode and delivered volume. Collaborates with Infusion Control for configuration acceptance; it cannot clear active unsafe alarms. [COMP-01@rb128b9c4](http://127.0.0.1:55279/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)

<!-- dhf-claim:ba979271b2179864 -->
Show operating mode and delivered volume. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-015@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/36?rev=1)

<!-- dhf-claim:b32e460352cb344a -->
Expose known residual anomalies to the operator. This behavior belongs to COMP-01 and prevents silent divergence between operator intent and delivered therapy. Reject invalid input explicitly and retain the prior validated state on failure. [SRS-032@r1](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/53?rev=1)


<!-- endsection:errors.UNIT-ui_status -->

<!-- section:allocation.UNIT-ui_status -->
### Allocated requirements and risk controls

| Requirement | Rev | Risk controls | 
| --- | --- | --- | 
| [SRS-015](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/36?rev=1) | 1 | — | 
| [SRS-032](http://127.0.0.1:55279/kestrel-org/Kestrel/_workitems/edit/53?rev=1) | 1 | — | 


<!-- endsection:allocation.UNIT-ui_status -->

<!-- section:tests.UNIT-ui_status -->
### Explicitly traced unit tests

No explicitly traced unit test case is recorded.


<!-- endsection:tests.UNIT-ui_status -->
