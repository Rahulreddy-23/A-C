# Design Review Record

<!-- section:identification -->
## Review identification

| Field | Provided value | 
| --- | --- | 
| type | Software design review | 
| date | 2026-10-12 | 
| baseline | sad-v1 | 
| participants | Synthetic Reviewer<br>Synthetic Design Engineer | 


<!-- endsection:identification -->

<!-- section:scope -->
## Changed evidence since baseline

| Artifact | Change | 
| --- | --- | 
| [SRS-021](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/42?rev=2) | changed | 
| [UNIT-sensor_pressure@a1d3651b](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GCbbd9a196a8b633928e1f13e9bd5baa42f35ff9bf) | changed | 
| [PR-8](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/8) | added | 
| [RES-3-021](http://127.0.0.1:64935/kestrel-org/Kestrel/_apis/test/runs/3/results/21) | added | 
| [RUN-3](http://127.0.0.1:64935/kestrel-org/Kestrel/_apis/test/runs/3) | added | 


<!-- endsection:scope -->

<!-- section:actions -->
## Previous action items

| Action | Description | State | 
| --- | --- | --- | 
| [ACT-01](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/123?rev=1) | Confirm pressure dwell boundary and retest evidence | Closed | 
| [ACT-02](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/124?rev=1) | Resolve alarm priority tie handling review | Closed | 
| [ACT-03](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/125?rev=1) | Record SOUP requirements and known-anomaly evaluations | Active | 
| [ACT-04](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/126?rev=1) | Implement and verify independent pressure plausibility control | Active | 


<!-- endsection:actions -->

<!-- section:findings_table -->
## Complete deterministic pre-review findings

| Rule | Count | Evidence | Recommended action | 
| --- | --- | --- | --- | 
| G01 | 4 | [SRS-012](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/33?rev=1)<br>[SRS-032](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/53?rev=1)<br>[SRS-034](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/55?rev=1)<br>[SRS-035](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | Add or link a verifying test for the requirement. | 
| G02 | 2 | [SRS-034](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/55?rev=1)<br>[SRS-035](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | Link an implementing change or record a justified implementation gap. | 
| G03 | 2 | [PR-7](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw/pullrequest/7)<br>[UNIT-diagnostics_trace@0e543199](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GC2298f2c5590a7dbcd1ac190b6ac1c3c30a82a015) | Link existing requirements or propose a requirement for human review. | 
| G04 | 1 | [TC-040](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/116?rev=1) | Link the test to its verified requirement or justify its standalone scope. | 
| G05 | 2 | [RES-1-021](http://127.0.0.1:64935/kestrel-org/Kestrel/_apis/test/runs/1/results/21)<br>[RES-3-021](http://127.0.0.1:64935/kestrel-org/Kestrel/_apis/test/runs/3/results/21) | Raise or link a defect for the failed result, or record a justified anomaly assessment. | 
| G06 | 1 | [RC-12](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/76?rev=1) | Trace the risk control to its realizing requirement. | 
| G07 | 1 | [SRS-012](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/33?rev=1) | Add verification evidence for the risk-control requirement. | 
| G08 | 1 | [SYS-015](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/21?rev=1) | Derive software requirements or justify non-software realization. | 
| G09 | 1 | [SRS-035](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/56?rev=1) | Link the parent system requirement or justify the requirement origin. | 
| G10 | 1 | [BUG-03](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/119?rev=1) | Include the open defect in residual anomalies with human-reviewed rationale. | 
| G11 | 2 | [TC-021](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/97?rev=1)<br>[TC-030](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/106?rev=1) | Rerun verification against the current requirement revision. | 
| G12 | 5 | [SOUP-01@39d9f63e](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt)<br>[SOUP-02@cf7f5c7e](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt)<br>[SOUP-03@6881c742](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt)<br>[SOUP-04@d50d45ce](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt)<br>[SOUP-05@dc66ace9](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/requirements.txt) | Record SOUP functional/performance requirements and evaluate its known anomaly list. | 
| C01 | 0 | — | No finding recorded. | 
| C02 | 8 | [SRS-021](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/42?rev=2)<br>[UNIT-sensor_pressure@a1d3651b](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GCbbd9a196a8b633928e1f13e9bd5baa42f35ff9bf) | Reconcile the baseline with current source before recording review decisions. | 
| C03 | 0 | — | No finding recorded. | 
| C04 | 0 | — | No finding recorded. | 
| F01 | 0 | — | No finding recorded. | 
| F02 | 1 | [RC-12](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/76?rev=1) | Record a requirement and verifying test for this control. | 
| F03 | 8 | [HAZ-01](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/57?rev=1)<br>[HAZ-02](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/58?rev=1)<br>[HAZ-03](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/59?rev=1)<br>[HAZ-04](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/60?rev=1)<br>[HAZ-05](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/61?rev=1)<br>[HAZ-06](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/62?rev=1)<br>[HAZ-07](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/63?rev=1)<br>[HAZ-08](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/64?rev=1) | Review proposed failure modes and record a confirmed analysis for this hazard. | 


<!-- endsection:findings_table -->

<!-- section:findings -->
## Pre-review findings

<!-- dhf-claim:d38df55d50d3f369 -->
**[Suggested — review required]** C02 flags SRS-021: sad baseline consistency finding. Recommended review action: Reconcile the baseline with current source before recording review decisions. [SRS-021@r2](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/42?rev=2)

<!-- dhf-claim:e6d8a715b516d668 -->
**[Suggested — review required]** C02 flags SRS-021: sdd baseline consistency finding. Recommended review action: Reconcile the baseline with current source before recording review decisions. [SRS-021@r2](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/42?rev=2)

<!-- dhf-claim:04881761fc0c4f62 -->
**[Suggested — review required]** C02 flags SRS-021: sfmea baseline consistency finding. Recommended review action: Reconcile the baseline with current source before recording review decisions. [SRS-021@r2](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/42?rev=2)

<!-- dhf-claim:017165737f4db02e -->
**[Suggested — review required]** C02 flags SRS-021: sstr baseline consistency finding. Recommended review action: Reconcile the baseline with current source before recording review decisions. [SRS-021@r2](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/42?rev=2)

<!-- dhf-claim:8f1e237d772727fb -->
**[Suggested — review required]** C02 flags UNIT-sensor_pressure: sad baseline consistency finding. Recommended review action: Reconcile the baseline with current source before recording review decisions. [UNIT-sensor_pressure@ra1d3651b](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GCbbd9a196a8b633928e1f13e9bd5baa42f35ff9bf)


<!-- endsection:findings -->

<!-- section:checklist -->
## Suggested checklist questions

<!-- dhf-claim:707d00599fc814ee -->
**[Suggested — review required]** What evidence closes C02 for SRS-021, and who will review the proposed disposition? [SRS-021@r2](http://127.0.0.1:64935/kestrel-org/Kestrel/_workitems/edit/42?rev=2)

<!-- dhf-claim:a45c52221e92fac8 -->
**[Suggested — review required]** What evidence closes C02 for UNIT-sensor_pressure, and who will review the proposed disposition? [UNIT-sensor_pressure@ra1d3651b](http://127.0.0.1:64935/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GCbbd9a196a8b633928e1f13e9bd5baa42f35ff9bf)


<!-- endsection:checklist -->

<!-- section:discussion -->
## Discussion and minutes

[Human input required — complete in the controlled review workflow.]

<!-- endsection:discussion -->

<!-- section:decisions -->
## Decisions

[Human input required — complete in the controlled review workflow.]

<!-- endsection:decisions -->

<!-- section:new_actions -->
## New action items

[Human input required — complete in the controlled review workflow.]

<!-- endsection:new_actions -->

<!-- section:approvals -->
## Approvals

[Human input required — complete in the controlled review workflow.]

<!-- endsection:approvals -->
