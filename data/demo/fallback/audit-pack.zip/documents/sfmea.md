# Software Failure Modes and Effects Analysis — Draft

<!-- section:inventory -->
## Component inventory

| Component | Name | Function | 
| --- | --- | --- | 
| [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | UI | Operator configuration and status | 
| [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Infusion Control | Validated delivery state and volume bounds | 
| [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Sensor Monitoring | Sample validation and occlusion/air detection | 
| [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Alarm Manager | Persistent critical alarm state | 
| [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Drug Library | Drug lookup and dose validation | 
| [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Logging & Comms | Ordered audit records and bounded communication | 


<!-- endsection:inventory -->

<!-- section:function_trace.UNIT-alarm_audio -->
## UNIT-alarm_audio: alarm_audio

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-alarm_audio@220f842d](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | AlertScheduler.tick | id: [HAZ-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1); name: Alarm unavailable; source severity: 5 | id: [RC-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/69?rev=1); title: Prioritised latched audible alarms and safe acknowledgement | [SRS-011](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/32?rev=1)<br>[SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1)<br>[SRS-013](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/34?rev=1)<br>[SRS-014](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/35?rev=1) | [TC-011](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/87?rev=1)<br>[TC-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/88?rev=1)<br>[TC-013](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/89?rev=1)<br>[TC-014](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/90?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-alarm_audio -->

<!-- section:function_modes.UNIT-alarm_audio -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:045d60b7084ce3ca -->Failure mode: AlertScheduler.tick fails to provide its required safe output [UNIT-alarm_audio@r220f842d](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:1f116f93b07b1a28 -->Cause: A boundary condition follows a path without the required validation [UNIT-alarm_audio@r220f842d](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:a57e31d0a93d009c -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-alarm_audio@r220f842d](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:0b47ed88c2bc3c3f -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-alarm_audio@r220f842d](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:8c917bcb008eb14c -->Recommended action: Review boundary and fault-injection tests for AlertScheduler.tick before confirming this mode. [UNIT-alarm_audio@r220f842d](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |


<!-- dhf-resolution:045d60b7084ce3ca accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:1f116f93b07b1a28 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:a57e31d0a93d009c accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:0b47ed88c2bc3c3f accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:8c917bcb008eb14c accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-alarm_audio -->

<!-- section:function_trace.UNIT-alarm_latch -->
## UNIT-alarm_latch: alarm_latch

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-alarm_latch@b36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | AlarmRegistry.acknowledge | id: [HAZ-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1); name: Undetected occlusion; source severity: 4<br>id: [HAZ-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1); name: Alarm unavailable; source severity: 5 | id: [RC-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/68?rev=1); title: Sustained-pressure occlusion detection with latched critical alarm<br>id: [RC-09](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/73?rev=1); title: Validated pressure samples and calibration<br>id: [RC-12](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/76?rev=1); title: Independent pressure-channel plausibility cross-check<br>id: [RC-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/69?rev=1); title: Prioritised latched audible alarms and safe acknowledgement | [SRS-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/30?rev=1)<br>[SRS-011](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/32?rev=1)<br>[SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1)<br>[SRS-013](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/34?rev=1)<br>[SRS-014](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/35?rev=1)<br>[SRS-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/42?rev=2)<br>[SRS-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/43?rev=1)<br>[SRS-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | [TC-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/85?rev=1)<br>[TC-011](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/87?rev=1)<br>[TC-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/88?rev=1)<br>[TC-013](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/89?rev=1)<br>[TC-014](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/90?rev=1)<br>[TC-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/97?rev=1)<br>[TC-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/98?rev=1)<br>[TC-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/99?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-alarm_latch -->

<!-- section:function_modes.UNIT-alarm_latch -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:3b8c805f03368725 -->**[Suggested — review required]** Failure mode: AlarmRegistry.acknowledge fails to provide its required safe output [UNIT-alarm_latch@rb36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:146918337b15c8c2 -->**[Suggested — review required]** Cause: A boundary condition follows a path without the required validation [UNIT-alarm_latch@rb36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:0ab696776a593814 -->**[Suggested — review required]** Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-alarm_latch@rb36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:804b3ad5a8db0c53 -->**[Suggested — review required]** System effect: The linked hazardous condition may persist without the intended software response [UNIT-alarm_latch@rb36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:7c191940d65127f6 -->**[Suggested — review required]** Recommended action: Review boundary and fault-injection tests for AlarmRegistry.acknowledge before confirming this mode. [UNIT-alarm_latch@rb36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |


<!-- endsection:function_modes.UNIT-alarm_latch -->

<!-- section:function_trace.UNIT-alarm_priority -->
## UNIT-alarm_priority: alarm_priority

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-alarm_priority@f71bb757](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | PrioritySelector.select | id: [HAZ-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1); name: Alarm unavailable; source severity: 5 | id: [RC-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/69?rev=1); title: Prioritised latched audible alarms and safe acknowledgement | [SRS-011](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/32?rev=1)<br>[SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1)<br>[SRS-013](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/34?rev=1)<br>[SRS-014](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/35?rev=1) | [TC-011](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/87?rev=1)<br>[TC-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/88?rev=1)<br>[TC-013](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/89?rev=1)<br>[TC-014](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/90?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-alarm_priority -->

<!-- section:function_modes.UNIT-alarm_priority -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:cd2e6cf398133224 -->Failure mode: PrioritySelector.select fails to provide its required safe output [UNIT-alarm_priority@rf71bb757](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:ce87c6c6195ec9c5 -->Cause: A boundary condition follows a path without the required validation [UNIT-alarm_priority@rf71bb757](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:ea754696562cd62d -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-alarm_priority@rf71bb757](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:a4befe2198a9e0c3 -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-alarm_priority@rf71bb757](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:2b741548f825bbb6 -->Recommended action: Review boundary and fault-injection tests for PrioritySelector.select before confirming this mode. [UNIT-alarm_priority@rf71bb757](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |


<!-- dhf-resolution:cd2e6cf398133224 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:ce87c6c6195ec9c5 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:ea754696562cd62d accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:a4befe2198a9e0c3 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:2b741548f825bbb6 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-alarm_priority -->

<!-- section:function_trace.UNIT-comms_frame -->
## UNIT-comms_frame: comms_frame

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-comms_frame@73b95536](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | FrameBuffer.append | — | — | — | — | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-comms_frame -->

<!-- section:function_modes.UNIT-comms_frame -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:922040384925dc0d -->Failure mode: FrameBuffer.append fails to provide its required safe output [UNIT-comms_frame@r73b95536](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) (confidence 0.5) |
| Cause | <!-- dhf-claim:03589c02fbe4024c -->Cause: A boundary condition follows a path without the required validation [UNIT-comms_frame@r73b95536](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) (confidence 0.5) |
| Local effect | <!-- dhf-claim:8bac89b5c0988377 -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-comms_frame@r73b95536](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) (confidence 0.5) |
| System effect | <!-- dhf-claim:92f1416cbcb12819 -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-comms_frame@r73b95536](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:e102272b12b68715 -->Recommended action: Review boundary and fault-injection tests for FrameBuffer.append before confirming this mode. [UNIT-comms_frame@r73b95536](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_frame.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) (confidence 0.5) |


<!-- dhf-resolution:922040384925dc0d accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:03589c02fbe4024c accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:8bac89b5c0988377 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:92f1416cbcb12819 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:e102272b12b68715 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-comms_frame -->

<!-- section:function_trace.UNIT-comms_timeout -->
## UNIT-comms_timeout: comms_timeout

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-comms_timeout@9f794d28](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Heartbeat.poll | id: [HAZ-08](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1); name: Unintended restart; source severity: 5 | id: [RC-08](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/72?rev=1); title: Watchdog inhibition and validated power-loss recovery | [SRS-029](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/50?rev=1)<br>[SRS-030](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/51?rev=2) | [TC-029](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/105?rev=1)<br>[TC-030](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/106?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-comms_timeout -->

<!-- section:function_modes.UNIT-comms_timeout -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:6bf281f378aa0436 -->Failure mode: Heartbeat.poll fails to provide its required safe output [UNIT-comms_timeout@r9f794d28](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:5350811183d946bb -->Cause: A boundary condition follows a path without the required validation [UNIT-comms_timeout@r9f794d28](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:e1c950dff1f4aa04 -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-comms_timeout@r9f794d28](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:5a0c55a6896d39fa -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-comms_timeout@r9f794d28](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:f18ae5a829d88b13 -->Recommended action: Review boundary and fault-injection tests for Heartbeat.poll before confirming this mode. [UNIT-comms_timeout@r9f794d28](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |


<!-- dhf-resolution:6bf281f378aa0436 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:5350811183d946bb accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:e1c950dff1f4aa04 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:5a0c55a6896d39fa accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:f18ae5a829d88b13 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-comms_timeout -->

<!-- section:function_trace.UNIT-diagnostics_trace -->
## UNIT-diagnostics_trace: diagnostics_trace

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-diagnostics_trace@0e543199](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GCc97b66528e09945be2a3fc3d2934dcdaaca42be7) | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | diagnostic_summary | — | — | — | — | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-diagnostics_trace -->

<!-- section:function_modes.UNIT-diagnostics_trace -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:87d5c03252d45e88 -->Failure mode: diagnostic_summary fails to provide its required safe output [UNIT-diagnostics_trace@r0e543199](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GCc97b66528e09945be2a3fc3d2934dcdaaca42be7) (confidence 0.5) |
| Cause | <!-- dhf-claim:944ba89198c525bc -->Cause: A boundary condition follows a path without the required validation [UNIT-diagnostics_trace@r0e543199](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GCc97b66528e09945be2a3fc3d2934dcdaaca42be7) (confidence 0.5) |
| Local effect | <!-- dhf-claim:82bd6d49e3211183 -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-diagnostics_trace@r0e543199](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GCc97b66528e09945be2a3fc3d2934dcdaaca42be7) (confidence 0.5) |
| System effect | <!-- dhf-claim:d4b24f599ad29893 -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-diagnostics_trace@r0e543199](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GCc97b66528e09945be2a3fc3d2934dcdaaca42be7) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:d00c8a037259be79 -->Recommended action: Review boundary and fault-injection tests for diagnostic_summary before confirming this mode. [UNIT-diagnostics_trace@r0e543199](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/diagnostics_trace.py&version=GCc97b66528e09945be2a3fc3d2934dcdaaca42be7) (confidence 0.5) |


<!-- dhf-resolution:87d5c03252d45e88 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:944ba89198c525bc accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:82bd6d49e3211183 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:d4b24f599ad29893 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:d00c8a037259be79 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-diagnostics_trace -->

<!-- section:function_trace.UNIT-drug_limits -->
## UNIT-drug_limits: drug_limits

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-drug_limits@e7d7f0a4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) | [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | DoseValidator.volume_for | id: [HAZ-06](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1); name: Incorrect drug limit; source severity: 4 | id: [RC-06](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/70?rev=1); title: Validated drug limits, lookup and library integrity | [SRS-018](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/39?rev=1)<br>[SRS-019](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/40?rev=1)<br>[SRS-020](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/41?rev=1) | [TC-018](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/94?rev=1)<br>[TC-019](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/95?rev=1)<br>[TC-020](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/96?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-drug_limits -->

<!-- section:function_modes.UNIT-drug_limits -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:6cc41b923a5c0416 -->Failure mode: DoseValidator.volume_for fails to provide its required safe output [UNIT-drug_limits@re7d7f0a4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:732326273e522639 -->Cause: A boundary condition follows a path without the required validation [UNIT-drug_limits@re7d7f0a4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:6420ca5fcf0725fa -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-drug_limits@re7d7f0a4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:09813d857fc1a03c -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-drug_limits@re7d7f0a4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:55603a38530f11f7 -->Recommended action: Review boundary and fault-injection tests for DoseValidator.volume_for before confirming this mode. [UNIT-drug_limits@re7d7f0a4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |


<!-- dhf-resolution:6cc41b923a5c0416 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:732326273e522639 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:6420ca5fcf0725fa accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:09813d857fc1a03c accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:55603a38530f11f7 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-drug_limits -->

<!-- section:function_trace.UNIT-drug_lookup -->
## UNIT-drug_lookup: drug_lookup

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-drug_lookup@9b215c47](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) | [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | DrugLibrary.select | id: [HAZ-06](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1); name: Incorrect drug limit; source severity: 4 | id: [RC-06](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/70?rev=1); title: Validated drug limits, lookup and library integrity | [SRS-018](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/39?rev=1)<br>[SRS-019](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/40?rev=1)<br>[SRS-020](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/41?rev=1) | [TC-018](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/94?rev=1)<br>[TC-019](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/95?rev=1)<br>[TC-020](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/96?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-drug_lookup -->

<!-- section:function_modes.UNIT-drug_lookup -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:9a2bd1b0aa0ca26e -->Failure mode: DrugLibrary.select fails to provide its required safe output [UNIT-drug_lookup@r9b215c47](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:e8ed9b1743c679a2 -->Cause: A boundary condition follows a path without the required validation [UNIT-drug_lookup@r9b215c47](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:27309d1336caa524 -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-drug_lookup@r9b215c47](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:749a43c109cc407f -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-drug_lookup@r9b215c47](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:cf9ebeca056f55ce -->Recommended action: Review boundary and fault-injection tests for DrugLibrary.select before confirming this mode. [UNIT-drug_lookup@r9b215c47](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |


<!-- dhf-resolution:9a2bd1b0aa0ca26e accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:e8ed9b1743c679a2 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:27309d1336caa524 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:749a43c109cc407f accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:cf9ebeca056f55ce accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-drug_lookup -->

<!-- section:function_trace.UNIT-infusion_bounds -->
## UNIT-infusion_bounds: infusion_bounds

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | DeliveryController.tick | id: [HAZ-01](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1); name: Over infusion; source severity: 5<br>id: [HAZ-08](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1); name: Unintended restart; source severity: 5 | id: [RC-01](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/65?rev=1); title: Bounded infusion rate and delivered volume<br>id: [RC-11](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/75?rev=1); title: Safe confirmation of therapy configuration<br>id: [RC-08](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/72?rev=1); title: Watchdog inhibition and validated power-loss recovery | [SRS-001](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/22?rev=1)<br>[SRS-002](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/23?rev=1)<br>[SRS-003](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/24?rev=1)<br>[SRS-017](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/38?rev=1)<br>[SRS-028](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/49?rev=1)<br>[SRS-029](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/50?rev=1)<br>[SRS-030](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/51?rev=2) | [TC-001](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/77?rev=1)<br>[TC-002](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/78?rev=1)<br>[TC-003](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/79?rev=1)<br>[TC-017](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/93?rev=1)<br>[TC-028](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/104?rev=1)<br>[TC-029](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/105?rev=1)<br>[TC-030](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/106?rev=1)<br>[TC-033](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/109?rev=1)<br>[TC-034](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/110?rev=1)<br>[TC-035](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/111?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-infusion_bounds -->

<!-- section:function_modes.UNIT-infusion_bounds -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:ca544cb0e33a13db -->Failure mode: DeliveryController.tick fails to provide its required safe output [UNIT-infusion_bounds@rbbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:2b73e53b8f44f7e6 -->Cause: A boundary condition follows a path without the required validation [UNIT-infusion_bounds@rbbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:c978b56ba9d08bf3 -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-infusion_bounds@rbbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:8e92d556ebb1b887 -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-infusion_bounds@rbbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:d3923d6b73400cf5 -->Recommended action: Review boundary and fault-injection tests for DeliveryController.tick before confirming this mode. [UNIT-infusion_bounds@rbbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |


<!-- dhf-resolution:ca544cb0e33a13db accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:2b73e53b8f44f7e6 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:c978b56ba9d08bf3 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:8e92d556ebb1b887 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:d3923d6b73400cf5 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-infusion_bounds -->

<!-- section:function_trace.UNIT-infusion_motor -->
## UNIT-infusion_motor: infusion_motor

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-infusion_motor@eb1bd363](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | MotorSchedule.pulses | id: [HAZ-02](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1); name: Under infusion; source severity: 4 | id: [RC-02](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/66?rev=1); title: Calibrated pulse scheduling and air-in-line inhibition | [SRS-006](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/27?rev=1)<br>[SRS-008](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/29?rev=1) | [TC-006](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/82?rev=1)<br>[TC-008](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/84?rev=1)<br>[TC-038](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/114?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-infusion_motor -->

<!-- section:function_modes.UNIT-infusion_motor -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:3a341a2ad3b1ca8b -->Failure mode: MotorSchedule.pulses fails to provide its required safe output [UNIT-infusion_motor@reb1bd363](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:70835a36550a099f -->Cause: A boundary condition follows a path without the required validation [UNIT-infusion_motor@reb1bd363](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:33f0fcdc29049cfe -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-infusion_motor@reb1bd363](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:7b947f1d7ee7ca9a -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-infusion_motor@reb1bd363](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:438904390d8f787c -->Recommended action: Review boundary and fault-injection tests for MotorSchedule.pulses before confirming this mode. [UNIT-infusion_motor@reb1bd363](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) (confidence 0.5) |


<!-- dhf-resolution:3a341a2ad3b1ca8b accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:70835a36550a099f accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:33f0fcdc29049cfe accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:7b947f1d7ee7ca9a accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:438904390d8f787c accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-infusion_motor -->

<!-- section:function_trace.UNIT-infusion_volume -->
## UNIT-infusion_volume: infusion_volume

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-infusion_volume@0b716c6e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | VolumeAccumulator.add | id: [HAZ-01](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1); name: Over infusion; source severity: 5 | id: [RC-01](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/65?rev=1); title: Bounded infusion rate and delivered volume<br>id: [RC-11](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/75?rev=1); title: Safe confirmation of therapy configuration | [SRS-001](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/22?rev=1)<br>[SRS-002](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/23?rev=1)<br>[SRS-003](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/24?rev=1)<br>[SRS-017](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/38?rev=1)<br>[SRS-028](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/49?rev=1) | [TC-001](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/77?rev=1)<br>[TC-002](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/78?rev=1)<br>[TC-003](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/79?rev=1)<br>[TC-017](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/93?rev=1)<br>[TC-028](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/104?rev=1)<br>[TC-033](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/109?rev=1)<br>[TC-034](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/110?rev=1)<br>[TC-035](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/111?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-infusion_volume -->

<!-- section:function_modes.UNIT-infusion_volume -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:837a0332bf1aaa72 -->Failure mode: VolumeAccumulator.add fails to provide its required safe output [UNIT-infusion_volume@r0b716c6e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:c57ae6f5c0f065a8 -->Cause: A boundary condition follows a path without the required validation [UNIT-infusion_volume@r0b716c6e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:dd5ff6bc735f492a -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-infusion_volume@r0b716c6e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:f731ce94f7a4a15e -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-infusion_volume@r0b716c6e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:7145cfb90976e4dd -->Recommended action: Review boundary and fault-injection tests for VolumeAccumulator.add before confirming this mode. [UNIT-infusion_volume@r0b716c6e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) (confidence 0.5) |


<!-- dhf-resolution:837a0332bf1aaa72 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:c57ae6f5c0f065a8 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:dd5ff6bc735f492a accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:f731ce94f7a4a15e accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:7145cfb90976e4dd accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-infusion_volume -->

<!-- section:function_trace.UNIT-log_digest -->
## UNIT-log_digest: log_digest

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-log_digest@ab99e552](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | IntegrityRecord.verify | id: [HAZ-07](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1); name: Lost audit evidence; source severity: 3 | id: [RC-07](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/71?rev=1); title: Ordered tamper-evident audit recording and export | [SRS-024](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/45?rev=1)<br>[SRS-025](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/46?rev=1)<br>[SRS-033](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/54?rev=1) | [TC-024](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/100?rev=1)<br>[TC-025](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/101?rev=1)<br>[TC-032](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/108?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-log_digest -->

<!-- section:function_modes.UNIT-log_digest -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:53c4e70b7bad4472 -->Failure mode: IntegrityRecord.verify fails to provide its required safe output [UNIT-log_digest@rab99e552](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:2a833879f2297894 -->Cause: A boundary condition follows a path without the required validation [UNIT-log_digest@rab99e552](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:0e52812cc0979166 -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-log_digest@rab99e552](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:1b82424adc48abdc -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-log_digest@rab99e552](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:1b286cab59d8ff36 -->Recommended action: Review boundary and fault-injection tests for IntegrityRecord.verify before confirming this mode. [UNIT-log_digest@rab99e552](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |


<!-- dhf-resolution:53c4e70b7bad4472 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:2a833879f2297894 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:0e52812cc0979166 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:1b82424adc48abdc accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:1b286cab59d8ff36 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-log_digest -->

<!-- section:function_trace.UNIT-log_events -->
## UNIT-log_events: log_events

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-log_events@92fbf9b0](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | EventRecorder.record | id: [HAZ-07](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1); name: Lost audit evidence; source severity: 3 | id: [RC-07](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/71?rev=1); title: Ordered tamper-evident audit recording and export | [SRS-024](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/45?rev=1)<br>[SRS-025](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/46?rev=1)<br>[SRS-033](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/54?rev=1) | [TC-024](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/100?rev=1)<br>[TC-025](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/101?rev=1)<br>[TC-032](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/108?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-log_events -->

<!-- section:function_modes.UNIT-log_events -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:3e2539563c8437af -->Failure mode: EventRecorder.record fails to provide its required safe output [UNIT-log_events@r92fbf9b0](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:e91f7c09a8d43fba -->Cause: A boundary condition follows a path without the required validation [UNIT-log_events@r92fbf9b0](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:ee282a5e2739da6b -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-log_events@r92fbf9b0](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:2b9356417aae0052 -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-log_events@r92fbf9b0](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:22f39d6358298285 -->Recommended action: Review boundary and fault-injection tests for EventRecorder.record before confirming this mode. [UNIT-log_events@r92fbf9b0](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |


<!-- dhf-resolution:3e2539563c8437af accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:e91f7c09a8d43fba accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:ee282a5e2739da6b accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:2b9356417aae0052 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:22f39d6358298285 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-log_events -->

<!-- section:function_trace.UNIT-sensor_air -->
## UNIT-sensor_air: sensor_air

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-sensor_air@f8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | AirMonitor.evaluate | id: [HAZ-02](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1); name: Under infusion; source severity: 4<br>id: [HAZ-03](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1); name: Air delivery; source severity: 5 | id: [RC-02](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/66?rev=1); title: Calibrated pulse scheduling and air-in-line inhibition<br>id: [RC-03](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/67?rev=1); title: Air-in-line detection and inhibited delivery<br>id: [RC-10](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/74?rev=1); title: Retained disconnected-sensor fault | [SRS-006](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/27?rev=1)<br>[SRS-008](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/29?rev=1)<br>[SRS-010](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/31?rev=1) | [TC-006](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/82?rev=1)<br>[TC-008](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/84?rev=1)<br>[TC-010](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/86?rev=1)<br>[TC-038](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/114?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-sensor_air -->

<!-- section:function_modes.UNIT-sensor_air -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:f87c727614cde144 -->Failure mode: AirMonitor.evaluate fails to provide its required safe output [UNIT-sensor_air@rf8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) [HAZ-03@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:e6f09d51b75d691a -->Cause: A boundary condition follows a path without the required validation [UNIT-sensor_air@rf8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) [HAZ-03@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:fc266a9734dc3b53 -->Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-sensor_air@rf8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) [HAZ-03@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:68d699404004f152 -->System effect: The linked hazardous condition may persist without the intended software response [UNIT-sensor_air@rf8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) [HAZ-03@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:77cd5e5357746e1c -->Recommended action: Review boundary and fault-injection tests for AirMonitor.evaluate before confirming this mode. [UNIT-sensor_air@rf8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) [HAZ-03@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) (confidence 0.5) |


<!-- dhf-resolution:f87c727614cde144 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:e6f09d51b75d691a accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:fc266a9734dc3b53 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:68d699404004f152 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:77cd5e5357746e1c accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:function_modes.UNIT-sensor_air -->

<!-- section:function_trace.UNIT-sensor_calibration -->
## UNIT-sensor_calibration: sensor_calibration

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-sensor_calibration@605da84b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Calibration.apply | id: [HAZ-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1); name: Undetected occlusion; source severity: 4 | id: [RC-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/68?rev=1); title: Sustained-pressure occlusion detection with latched critical alarm<br>id: [RC-09](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/73?rev=1); title: Validated pressure samples and calibration<br>id: [RC-12](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/76?rev=1); title: Independent pressure-channel plausibility cross-check | [SRS-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/30?rev=1)<br>[SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1)<br>[SRS-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/42?rev=2)<br>[SRS-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/43?rev=1)<br>[SRS-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | [TC-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/85?rev=1)<br>[TC-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/97?rev=1)<br>[TC-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/98?rev=1)<br>[TC-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/99?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-sensor_calibration -->

<!-- section:function_modes.UNIT-sensor_calibration -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:dd539b7eb69b52da -->**[Suggested — review required]** Failure mode: Calibration.apply fails to provide its required safe output [UNIT-sensor_calibration@r605da84b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:ca959f4a5764dece -->**[Suggested — review required]** Cause: A boundary condition follows a path without the required validation [UNIT-sensor_calibration@r605da84b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:f33a07f9de6b2ce6 -->**[Suggested — review required]** Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-sensor_calibration@r605da84b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:d82e016e0c64527c -->**[Suggested — review required]** System effect: The linked hazardous condition may persist without the intended software response [UNIT-sensor_calibration@r605da84b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:7409a600e667320a -->**[Suggested — review required]** Recommended action: Review boundary and fault-injection tests for Calibration.apply before confirming this mode. [UNIT-sensor_calibration@r605da84b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |


<!-- endsection:function_modes.UNIT-sensor_calibration -->

<!-- section:function_trace.UNIT-sensor_filter -->
## UNIT-sensor_filter: sensor_filter

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-sensor_filter@8b9b8bc9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | PressureWindow.append | id: [HAZ-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1); name: Undetected occlusion; source severity: 4 | id: [RC-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/68?rev=1); title: Sustained-pressure occlusion detection with latched critical alarm<br>id: [RC-09](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/73?rev=1); title: Validated pressure samples and calibration<br>id: [RC-12](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/76?rev=1); title: Independent pressure-channel plausibility cross-check | [SRS-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/30?rev=1)<br>[SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1)<br>[SRS-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/42?rev=2)<br>[SRS-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/43?rev=1)<br>[SRS-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | [TC-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/85?rev=1)<br>[TC-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/97?rev=1)<br>[TC-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/98?rev=1)<br>[TC-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/99?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-sensor_filter -->

<!-- section:function_modes.UNIT-sensor_filter -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:63a9697c229bf7cd -->**[Suggested — review required]** Failure mode: PressureWindow.append fails to provide its required safe output [UNIT-sensor_filter@r8b9b8bc9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:b59de7887f75fc21 -->**[Suggested — review required]** Cause: A boundary condition follows a path without the required validation [UNIT-sensor_filter@r8b9b8bc9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:59f97499b79fea9e -->**[Suggested — review required]** Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-sensor_filter@r8b9b8bc9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:dd2ff6b6c8d9fd7e -->**[Suggested — review required]** System effect: The linked hazardous condition may persist without the intended software response [UNIT-sensor_filter@r8b9b8bc9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:3250fbc7b2ee7d9d -->**[Suggested — review required]** Recommended action: Review boundary and fault-injection tests for PressureWindow.append before confirming this mode. [UNIT-sensor_filter@r8b9b8bc9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |


<!-- endsection:function_modes.UNIT-sensor_filter -->

<!-- section:function_trace.UNIT-sensor_pressure -->
## UNIT-sensor_pressure: sensor_pressure

### Safety-relevant function source trace

| Unit | Component | Extracted function | Hazard / source severity | Existing controls | Requirements | Detection / verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | --- | --- | 
| [UNIT-sensor_pressure@a1d3651b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC54a17a8b49227a82c3749ac902cb3af4f907b2d2) | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | PressureMonitor.evaluate | id: [HAZ-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1); name: Undetected occlusion; source severity: 4 | id: [RC-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/68?rev=1); title: Sustained-pressure occlusion detection with latched critical alarm<br>id: [RC-09](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/73?rev=1); title: Validated pressure samples and calibration<br>id: [RC-12](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/76?rev=1); title: Independent pressure-channel plausibility cross-check | [SRS-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/30?rev=1)<br>[SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1)<br>[SRS-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/42?rev=2)<br>[SRS-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/43?rev=1)<br>[SRS-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | [TC-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/85?rev=1)<br>[TC-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/97?rev=1)<br>[TC-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/98?rev=1)<br>[TC-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/99?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:function_trace.UNIT-sensor_pressure -->

<!-- section:function_modes.UNIT-sensor_pressure -->
### Function failure mode — proposed analysis

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:bf60e0ada7a68145 -->**[Suggested — review required]** Failure mode: PressureMonitor.evaluate fails to provide its required safe output [UNIT-sensor_pressure@ra1d3651b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC54a17a8b49227a82c3749ac902cb3af4f907b2d2) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:6c439fd47e866cdb -->**[Suggested — review required]** Cause: A boundary condition follows a path without the required validation [UNIT-sensor_pressure@ra1d3651b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC54a17a8b49227a82c3749ac902cb3af4f907b2d2) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:c5e888ef397bc0f1 -->**[Suggested — review required]** Local effect: The returned output or retained state is inconsistent with the sampled condition [UNIT-sensor_pressure@ra1d3651b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC54a17a8b49227a82c3749ac902cb3af4f907b2d2) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:9a43b0d0b2f963a2 -->**[Suggested — review required]** System effect: The linked hazardous condition may persist without the intended software response [UNIT-sensor_pressure@ra1d3651b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC54a17a8b49227a82c3749ac902cb3af4f907b2d2) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:9ffbbb4390b26443 -->**[Suggested — review required]** Recommended action: Review boundary and fault-injection tests for PressureMonitor.evaluate before confirming this mode. [UNIT-sensor_pressure@ra1d3651b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC54a17a8b49227a82c3749ac902cb3af4f907b2d2) [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |


<!-- endsection:function_modes.UNIT-sensor_pressure -->

<!-- section:risk_row.HAZ-01 -->
## HAZ-01: Over infusion

### Risk source and trace

| Hazard | Hazard name | Source severity | Components | Function | Function analysis rows (unit IDs) | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-01](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) | Over infusion | 5 | [COMP-01@b128b9c4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)<br>[COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Operator configuration and status; Validated delivery state and volume bounds | [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39)<br>[UNIT-infusion_volume@0b716c6e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39)<br>[UNIT-ui_confirm@4a6745ab](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_confirm.py&version=GC9a5adaf3b72e4a7563cc55ae3362488dad220bea) | 


<!-- endsection:risk_row.HAZ-01 -->

<!-- section:control_trace.HAZ-01 -->
### Controls and verification

| Hazard | Units | Recorded controls | Requirements | Verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-01](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) | [UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39)<br>[UNIT-infusion_volume@0b716c6e](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_volume.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39)<br>[UNIT-ui_confirm@4a6745ab](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/ui_confirm.py&version=GC9a5adaf3b72e4a7563cc55ae3362488dad220bea) | id: [RC-01](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/65?rev=1); title: Bounded infusion rate and delivered volume<br>id: [RC-11](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/75?rev=1); title: Safe confirmation of therapy configuration | [SRS-001](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/22?rev=1)<br>[SRS-002](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/23?rev=1)<br>[SRS-003](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/24?rev=1)<br>[SRS-017](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/38?rev=1)<br>[SRS-028](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/49?rev=1) | [TC-001](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/77?rev=1)<br>[TC-002](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/78?rev=1)<br>[TC-003](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/79?rev=1)<br>[TC-017](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/93?rev=1)<br>[TC-028](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/104?rev=1)<br>[TC-033](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/109?rev=1)<br>[TC-034](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/110?rev=1)<br>[TC-035](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/111?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:control_trace.HAZ-01 -->

<!-- section:failure_modes.HAZ-01 -->
### Proposed failure mode, cause and effects

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:b68ff860a846b450 -->Failure mode: Over infusion [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:4c420a6fa7b1f230 -->Cause: Rate or accumulated-volume limits bypassed [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:0c9ad8cb3b86a7c7 -->Local effect: Unsafe output or retained state does not reflect the initiating condition [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:80a3a7a7b42fe758 -->System effect: Life-threatening fluid overdose [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:8b31ca38ad2a86b7 -->Recommended action: Review recorded controls and verification before accepting this analysis. [HAZ-01@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) (confidence 0.5) |


<!-- dhf-resolution:b68ff860a846b450 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:4c420a6fa7b1f230 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:0c9ad8cb3b86a7c7 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:80a3a7a7b42fe758 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:8b31ca38ad2a86b7 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:failure_modes.HAZ-01 -->

<!-- section:risk_row.HAZ-02 -->
## HAZ-02: Under infusion

### Risk source and trace

| Hazard | Hazard name | Source severity | Components | Function | Function analysis rows (unit IDs) | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-02](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) | Under infusion | 4 | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)<br>[COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Validated delivery state and volume bounds; Sample validation and occlusion/air detection | [UNIT-infusion_motor@eb1bd363](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39)<br>[UNIT-sensor_air@f8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) | 


<!-- endsection:risk_row.HAZ-02 -->

<!-- section:control_trace.HAZ-02 -->
### Controls and verification

| Hazard | Units | Recorded controls | Requirements | Verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-02](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) | [UNIT-infusion_motor@eb1bd363](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_motor.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39)<br>[UNIT-sensor_air@f8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) | id: [RC-02](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/66?rev=1); title: Calibrated pulse scheduling and air-in-line inhibition | [SRS-006](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/27?rev=1)<br>[SRS-008](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/29?rev=1) | [TC-006](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/82?rev=1)<br>[TC-008](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/84?rev=1)<br>[TC-038](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/114?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:control_trace.HAZ-02 -->

<!-- section:failure_modes.HAZ-02 -->
### Proposed failure mode, cause and effects

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:6b9fa27f67df0cd5 -->Failure mode: Under infusion [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:b8b2355f76a0b4af -->Cause: Motor stops without a sustained operator alert [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:6480d70a2a8fc43c -->Local effect: Unsafe output or retained state does not reflect the initiating condition [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:83d6137273c521b6 -->System effect: Interrupted therapy requiring intervention [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:06dd3e1886d4bcbe -->Recommended action: Review recorded controls and verification before accepting this analysis. [HAZ-02@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) (confidence 0.5) |


<!-- dhf-resolution:6b9fa27f67df0cd5 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:b8b2355f76a0b4af accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:6480d70a2a8fc43c accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:83d6137273c521b6 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:06dd3e1886d4bcbe accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:failure_modes.HAZ-02 -->

<!-- section:risk_row.HAZ-03 -->
## HAZ-03: Air delivery

### Risk source and trace

| Hazard | Hazard name | Source severity | Components | Function | Function analysis rows (unit IDs) | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-03](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) | Air delivery | 5 | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Sample validation and occlusion/air detection | [UNIT-sensor_air@f8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) | 


<!-- endsection:risk_row.HAZ-03 -->

<!-- section:control_trace.HAZ-03 -->
### Controls and verification

| Hazard | Units | Recorded controls | Requirements | Verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-03](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) | [UNIT-sensor_air@f8cd0f72](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_air.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7) | id: [RC-03](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/67?rev=1); title: Air-in-line detection and inhibited delivery<br>id: [RC-10](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/74?rev=1); title: Retained disconnected-sensor fault | [SRS-008](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/29?rev=1)<br>[SRS-010](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/31?rev=1) | [TC-008](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/84?rev=1)<br>[TC-010](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/86?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:control_trace.HAZ-03 -->

<!-- section:failure_modes.HAZ-03 -->
### Proposed failure mode, cause and effects

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:701c01c3581870a8 -->Failure mode: Air delivery [HAZ-03@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:4037fd51fd143739 -->Cause: Air sensor fault or threshold not enforced [HAZ-03@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:9c88dd148c1f2e61 -->Local effect: Unsafe output or retained state does not reflect the initiating condition [HAZ-03@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:1cd659a35ea28d99 -->System effect: Air embolism with serious injury [HAZ-03@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:11c27d55c3f443c9 -->Recommended action: Review recorded controls and verification before accepting this analysis. [HAZ-03@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) (confidence 0.5) |


<!-- dhf-resolution:701c01c3581870a8 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:4037fd51fd143739 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:9c88dd148c1f2e61 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:1cd659a35ea28d99 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:11c27d55c3f443c9 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:failure_modes.HAZ-03 -->

<!-- section:risk_row.HAZ-04 -->
## HAZ-04: Undetected occlusion

### Risk source and trace

| Hazard | Hazard name | Source severity | Components | Function | Function analysis rows (unit IDs) | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) | Undetected occlusion | 4 | [COMP-03@9ae26fe4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)<br>[COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Sample validation and occlusion/air detection; Persistent critical alarm state | [UNIT-alarm_latch@b36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81)<br>[UNIT-sensor_calibration@605da84b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7)<br>[UNIT-sensor_filter@8b9b8bc9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7)<br>[UNIT-sensor_pressure@a1d3651b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC54a17a8b49227a82c3749ac902cb3af4f907b2d2) | 


<!-- endsection:risk_row.HAZ-04 -->

<!-- section:control_trace.HAZ-04 -->
### Controls and verification

| Hazard | Units | Recorded controls | Requirements | Verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) | [UNIT-alarm_latch@b36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81)<br>[UNIT-sensor_calibration@605da84b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_calibration.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7)<br>[UNIT-sensor_filter@8b9b8bc9](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_filter.py&version=GC9ff9fa17eb7617d681339176849a8cb9120d36b7)<br>[UNIT-sensor_pressure@a1d3651b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/sensor_pressure.py&version=GC54a17a8b49227a82c3749ac902cb3af4f907b2d2) | id: [RC-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/68?rev=1); title: Sustained-pressure occlusion detection with latched critical alarm<br>id: [RC-09](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/73?rev=1); title: Validated pressure samples and calibration<br>id: [RC-12](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/76?rev=1); title: Independent pressure-channel plausibility cross-check | [SRS-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/30?rev=1)<br>[SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1)<br>[SRS-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/42?rev=2)<br>[SRS-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/43?rev=1)<br>[SRS-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/44?rev=1) | [TC-009](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/85?rev=1)<br>[TC-021](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/97?rev=1)<br>[TC-022](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/98?rev=1)<br>[TC-023](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/99?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:control_trace.HAZ-04 -->

<!-- section:failure_modes.HAZ-04 -->
### Proposed failure mode, cause and effects

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:f5d8a50f302946db -->**[Suggested — review required]** Failure mode: Undetected occlusion [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:80a167b059a31488 -->**[Suggested — review required]** Cause: Pressure sampling or alarm latency exceeds control limits [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:ed445f1a0715c460 -->**[Suggested — review required]** Local effect: Unsafe output or retained state does not reflect the initiating condition [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:eb0963b29d1ae382 -->**[Suggested — review required]** System effect: Delayed therapy and potential serious deterioration [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:20310d437ef36b3e -->**[Suggested — review required]** Recommended action: Review recorded controls and verification before accepting this analysis. [HAZ-04@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) (confidence 0.5) |


<!-- endsection:failure_modes.HAZ-04 -->

<!-- section:risk_row.HAZ-05 -->
## HAZ-05: Alarm unavailable

### Risk source and trace

| Hazard | Hazard name | Source severity | Components | Function | Function analysis rows (unit IDs) | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) | Alarm unavailable | 5 | [COMP-04@eec25a71](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Persistent critical alarm state | [UNIT-alarm_audio@220f842d](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81)<br>[UNIT-alarm_latch@b36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81)<br>[UNIT-alarm_priority@f71bb757](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) | 


<!-- endsection:risk_row.HAZ-05 -->

<!-- section:control_trace.HAZ-05 -->
### Controls and verification

| Hazard | Units | Recorded controls | Requirements | Verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) | [UNIT-alarm_audio@220f842d](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_audio.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81)<br>[UNIT-alarm_latch@b36fa4fc](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_latch.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81)<br>[UNIT-alarm_priority@f71bb757](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/alarm_priority.py&version=GC80ba5a325d03399b189a387159ea908c9f6ebc81) | id: [RC-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/69?rev=1); title: Prioritised latched audible alarms and safe acknowledgement | [SRS-011](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/32?rev=1)<br>[SRS-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/33?rev=1)<br>[SRS-013](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/34?rev=1)<br>[SRS-014](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/35?rev=1) | [TC-011](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/87?rev=1)<br>[TC-012](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/88?rev=1)<br>[TC-013](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/89?rev=1)<br>[TC-014](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/90?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:control_trace.HAZ-05 -->

<!-- section:failure_modes.HAZ-05 -->
### Proposed failure mode, cause and effects

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:7bfd71364773e4d6 -->Failure mode: Alarm unavailable [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:ddfc1d2d42eb0409 -->Cause: Alarm output unavailable during a critical fault [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:4d8cb8ef0acc7ad7 -->Local effect: Unsafe output or retained state does not reflect the initiating condition [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:e2f15be8bb4ea23c -->System effect: Unsafe delivery continuing without operator warning [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:5d08b834f15c2a77 -->Recommended action: Review recorded controls and verification before accepting this analysis. [HAZ-05@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) (confidence 0.5) |


<!-- dhf-resolution:7bfd71364773e4d6 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:ddfc1d2d42eb0409 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:4d8cb8ef0acc7ad7 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:e2f15be8bb4ea23c accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:5d08b834f15c2a77 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:failure_modes.HAZ-05 -->

<!-- section:risk_row.HAZ-06 -->
## HAZ-06: Incorrect drug limit

### Risk source and trace

| Hazard | Hazard name | Source severity | Components | Function | Function analysis rows (unit IDs) | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-06](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) | Incorrect drug limit | 4 | [COMP-05@17b6bad7](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Drug lookup and dose validation | [UNIT-drug_limits@e7d7f0a4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460)<br>[UNIT-drug_lookup@9b215c47](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) | 


<!-- endsection:risk_row.HAZ-06 -->

<!-- section:control_trace.HAZ-06 -->
### Controls and verification

| Hazard | Units | Recorded controls | Requirements | Verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-06](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) | [UNIT-drug_limits@e7d7f0a4](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_limits.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460)<br>[UNIT-drug_lookup@9b215c47](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/drug_lookup.py&version=GC12a74b9e9ecd647669ea5b9bb9f70c0933854460) | id: [RC-06](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/70?rev=1); title: Validated drug limits, lookup and library integrity | [SRS-018](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/39?rev=1)<br>[SRS-019](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/40?rev=1)<br>[SRS-020](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/41?rev=1) | [TC-018](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/94?rev=1)<br>[TC-019](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/95?rev=1)<br>[TC-020](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/96?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:control_trace.HAZ-06 -->

<!-- section:failure_modes.HAZ-06 -->
### Proposed failure mode, cause and effects

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:6c71eced93641c7c -->Failure mode: Incorrect drug limit [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:3006aee4ce24a2aa -->Cause: Library corruption or invalid dose limits accepted [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:0e95383d2daaa175 -->Local effect: Unsafe output or retained state does not reflect the initiating condition [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:bb9c13eed15043f8 -->System effect: Incorrect medication delivery causing serious injury [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:7df1d2669147a68e -->Recommended action: Review recorded controls and verification before accepting this analysis. [HAZ-06@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) (confidence 0.5) |


<!-- dhf-resolution:6c71eced93641c7c accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:3006aee4ce24a2aa accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:0e95383d2daaa175 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:bb9c13eed15043f8 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:7df1d2669147a68e accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:failure_modes.HAZ-06 -->

<!-- section:risk_row.HAZ-07 -->
## HAZ-07: Lost audit evidence

### Risk source and trace

| Hazard | Hazard name | Source severity | Components | Function | Function analysis rows (unit IDs) | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-07](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) | Lost audit evidence | 3 | [COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Ordered audit records and bounded communication | [UNIT-log_digest@ab99e552](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30)<br>[UNIT-log_events@92fbf9b0](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) | 


<!-- endsection:risk_row.HAZ-07 -->

<!-- section:control_trace.HAZ-07 -->
### Controls and verification

| Hazard | Units | Recorded controls | Requirements | Verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-07](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) | [UNIT-log_digest@ab99e552](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_digest.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30)<br>[UNIT-log_events@92fbf9b0](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/log_events.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30) | id: [RC-07](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/71?rev=1); title: Ordered tamper-evident audit recording and export | [SRS-024](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/45?rev=1)<br>[SRS-025](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/46?rev=1)<br>[SRS-033](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/54?rev=1) | [TC-024](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/100?rev=1)<br>[TC-025](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/101?rev=1)<br>[TC-032](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/108?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:control_trace.HAZ-07 -->

<!-- section:failure_modes.HAZ-07 -->
### Proposed failure mode, cause and effects

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:91f63cda2e0a8a6d -->Failure mode: Lost audit evidence [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:7245dcf0961f8773 -->Cause: Event storage is lost or its ordering is corrupted [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:45c89fd3ee0e32c1 -->Local effect: Unsafe output or retained state does not reflect the initiating condition [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:50cf5f3dd13a8254 -->System effect: Unavailable event evidence delays corrective action [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:f5570ae8c367f28b -->Recommended action: Review recorded controls and verification before accepting this analysis. [HAZ-07@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) (confidence 0.5) |


<!-- dhf-resolution:91f63cda2e0a8a6d accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:7245dcf0961f8773 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:45c89fd3ee0e32c1 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:50cf5f3dd13a8254 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:f5570ae8c367f28b accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:failure_modes.HAZ-07 -->

<!-- section:risk_row.HAZ-08 -->
## HAZ-08: Unintended restart

### Risk source and trace

| Hazard | Hazard name | Source severity | Components | Function | Function analysis rows (unit IDs) | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-08](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) | Unintended restart | 5 | [COMP-02@d5c8005b](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml)<br>[COMP-06@c50ffebb](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/architecture.yaml) | Validated delivery state and volume bounds; Ordered audit records and bounded communication | [UNIT-comms_timeout@9f794d28](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30)<br>[UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) | 


<!-- endsection:risk_row.HAZ-08 -->

<!-- section:control_trace.HAZ-08 -->
### Controls and verification

| Hazard | Units | Recorded controls | Requirements | Verification | Residual risk | 
| --- | --- | --- | --- | --- | --- | 
| [HAZ-08](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) | [UNIT-comms_timeout@9f794d28](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/comms_timeout.py&version=GCac919ea6d08aa628a291a9359ecb7c1f65a00f30)<br>[UNIT-infusion_bounds@bbfec6aa](http://127.0.0.1:56251/kestrel-org/Kestrel/_git/kestrel-device-sw?path=/kestrel/infusion_bounds.py&version=GCf962fe86b1327f7f8d5750f8c8dcd511bd1abb39) | id: [RC-08](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/72?rev=1); title: Watchdog inhibition and validated power-loss recovery | [SRS-029](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/50?rev=1)<br>[SRS-030](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/51?rev=2) | [TC-029](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/105?rev=1)<br>[TC-030](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/106?rev=1) | Human assessment required — no acceptance recorded | 


<!-- endsection:control_trace.HAZ-08 -->

<!-- section:failure_modes.HAZ-08 -->
### Proposed failure mode, cause and effects

| Proposed analysis cell | Draft — human review required |
|---|---|
| Failure mode | <!-- dhf-claim:6c3c8e59fb76303a -->Failure mode: Unintended restart [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| Cause | <!-- dhf-claim:5de3060f42421dcb -->Cause: Unvalidated stored configuration is resumed automatically [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| Local effect | <!-- dhf-claim:d85b47a9d0c27d21 -->Local effect: Unsafe output or retained state does not reflect the initiating condition [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| System effect | <!-- dhf-claim:73898b7f1be96cea -->System effect: Unexpected delivery after restart causes overdose [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |
| Recommended action | <!-- dhf-claim:76eace59e7df4660 -->Recommended action: Review recorded controls and verification before accepting this analysis. [HAZ-08@r1](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) (confidence 0.5) |


<!-- dhf-resolution:6c3c8e59fb76303a accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:5de3060f42421dcb accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:d85b47a9d0c27d21 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:73898b7f1be96cea accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- dhf-resolution:76eace59e7df4660 accepted reviewer=SyntheticDemoReviewer rationale=Fixture draft completeness reviewed; eQMS approval pending -->
<!-- endsection:failure_modes.HAZ-08 -->

<!-- section:risk_acceptance -->
## Residual-risk assessment and acceptance

Synthetic reviewer supplied draft content. eQMS approval remains pending.

<!-- endsection:risk_acceptance -->

<!-- section:gaps -->
## Risk analysis gaps

| Rule | Evidence | Recommended action | 
| --- | --- | --- | 
| F03 | [HAZ-01](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/57?rev=1) | Review proposed failure modes and record a confirmed analysis for this hazard. | 
| F03 | [HAZ-02](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/58?rev=1) | Review proposed failure modes and record a confirmed analysis for this hazard. | 
| F03 | [HAZ-03](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/59?rev=1) | Review proposed failure modes and record a confirmed analysis for this hazard. | 
| F03 | [HAZ-04](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/60?rev=1) | Review proposed failure modes and record a confirmed analysis for this hazard. | 
| F03 | [HAZ-05](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/61?rev=1) | Review proposed failure modes and record a confirmed analysis for this hazard. | 
| F03 | [HAZ-06](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/62?rev=1) | Review proposed failure modes and record a confirmed analysis for this hazard. | 
| F03 | [HAZ-07](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/63?rev=1) | Review proposed failure modes and record a confirmed analysis for this hazard. | 
| F03 | [HAZ-08](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/64?rev=1) | Review proposed failure modes and record a confirmed analysis for this hazard. | 
| F02 | [RC-12](http://127.0.0.1:56251/kestrel-org/Kestrel/_workitems/edit/76?rev=1) | Record a requirement and verifying test for this control. | 


<!-- endsection:gaps -->
